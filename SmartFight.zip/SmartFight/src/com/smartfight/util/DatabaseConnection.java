package com.smartfight.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Gestionnaire de connexion à la base de données avec reconnexion automatique
 */
public class DatabaseConnection {

    private static final String URL      = "jdbc:mysql://localhost:3306/smartfight" +
                                           "?autoReconnect=true&useSSL=false" +
                                           "&allowPublicKeyRetrieval=true" +
                                           "&serverTimezone=UTC";
    private static final String USER     = "root";
    private static final String PASSWORD = "";

    private static Connection connection = null;

    /**
     * Retourne une connexion valide, en reconnectant si nécessaire
     */
    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            if (connection == null || connection.isClosed() || !connection.isValid(3)) {
                System.out.println("🔄 (Re)connexion à la base de données...");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("✓ Connexion établie");
            }

        } catch (ClassNotFoundException e) {
            System.err.println("❌ Driver MySQL non trouvé !");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("❌ Erreur de connexion: " + e.getMessage());
            e.printStackTrace();
            connection = null;
        }
        return connection;
    }

    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                connection = null;
                System.out.println("✓ Connexion fermée");
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur fermeture: " + e.getMessage());
        }
    }

    public static boolean testConnection() {
        try {
            Connection conn = getConnection();
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }
}