package com.smartfight.view.scenes;

import com.smartfight.controller.MainController;
import com.smartfight.model.Fighter;
import com.smartfight.model.MatchProposal;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

/**
 * Scène Matchmaking - Génération et visualisation des matchs
 * VERSION AMÉLIORÉE - Sélection combattant + meilleur adversaire AI
 */
public class MatchmakingScene {
    private MainController controller;
    private BorderPane view;
    private TableView<MatchProposal> table;
    private TextArea txtDetails;
    private Spinner<Integer> spinnerMaxMatches;
    private Label lblMatchCount;

    // ── Nouveaux composants pour la sélection de combattant ──
    private ComboBox<Fighter> comboFighter;
    private Label lblBestOpponent;
    private VBox bestOpponentCard;

    public MatchmakingScene(MainController controller) {
        if (controller == null) {
            throw new IllegalArgumentException("Le contrôleur ne peut pas être null");
        }
        this.controller = controller;
        initializeUI();
    }

    private void initializeUI() {
        view = new BorderPane();
        view.setPadding(new Insets(30));
        view.setStyle("-fx-background-color: #f5f5f5;");

        // Header
        VBox header = createHeader();
        view.setTop(header);

        // Contenu principal : panneau AI gauche + table droite
        HBox mainContent = new HBox(20);
        mainContent.setPadding(new Insets(20, 0, 0, 0));

        // Panneau gauche : sélection + meilleur adversaire
        VBox leftPanel = createAIPanel();
        leftPanel.setPrefWidth(320);
        leftPanel.setMinWidth(300);

        // Panneau droit : table + détails
        VBox rightPanel = createRightPanel();
        HBox.setHgrow(rightPanel, Priority.ALWAYS);

        mainContent.getChildren().addAll(leftPanel, rightPanel);
        view.setCenter(mainContent);
    }

    private VBox createHeader() {
        VBox header = new VBox(15);

        Label title = new Label("⚔️ Matchmaking Intelligent");
        title.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        Label subtitle = new Label("Génération automatique des combats basée sur l'IA");
        subtitle.setStyle("-fx-font-size: 14px; -fx-text-fill: #7f8c8d;");

        HBox actionBar = new HBox(15);
        actionBar.setAlignment(Pos.CENTER_LEFT);

        Label lblMaxMatches = new Label("Nombre de matchs:");
        lblMaxMatches.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        spinnerMaxMatches = new Spinner<>(1, 50, 10);
        spinnerMaxMatches.setPrefWidth(80);
        spinnerMaxMatches.setStyle("-fx-font-size: 14px;");
        spinnerMaxMatches.setEditable(true);

        Button btnGenerate = new Button("🎲 Générer tous les matchs");
        btnGenerate.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; " +
                "-fx-font-size: 14px; -fx-padding: 10 20; -fx-cursor: hand; " +
                "-fx-font-weight: bold; -fx-background-radius: 5;");
        btnGenerate.setOnAction(e -> generateMatches());

        Button btnClear = new Button("🗑️Effacer");
        btnClear.setStyle("-fx-background-color: #95a5a6; -fx-text-fill: white; " +
                "-fx-font-size: 14px; -fx-padding: 10 20; -fx-cursor: hand; " +
                "-fx-background-radius: 5;");
        btnClear.setOnAction(e -> clearMatches());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        lblMatchCount = new Label("0 match généré");
        lblMatchCount.setStyle("-fx-font-size: 14px; -fx-text-fill: #7f8c8d; -fx-font-weight: bold;");

        actionBar.getChildren().addAll(lblMaxMatches, spinnerMaxMatches, btnGenerate, btnClear, spacer, lblMatchCount);
        header.getChildren().addAll(title, subtitle, actionBar);
        return header;
    }

    /**
     * Panneau gauche : sélection combattant + résultat AI
     */
    private VBox createAIPanel() {
        VBox panel = new VBox(15);
        panel.setPadding(new Insets(20));
        panel.setStyle("-fx-background-color: white; -fx-background-radius: 10; " +
                "-fx-border-color: #dfe6e9; -fx-border-radius: 10; -fx-border-width: 1; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 8, 0, 0, 2);");

        // Titre panneau
        Label panelTitle = new Label("🤖 Trouver Meilleur Adversaire");
        panelTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        Label panelSubtitle = new Label("L'IA analyse les stats pour proposer\nle match le plus équilibré");
        panelSubtitle.setStyle("-fx-font-size: 12px; -fx-text-fill: #7f8c8d;");

        Separator sep1 = new Separator();

        // Sélection du combattant
        Label lblSelect = new Label("Sélectionner un combattant :");
        lblSelect.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: #34495e;");

        comboFighter = new ComboBox<>();
        comboFighter.setItems(controller.getFighters());
        comboFighter.setPromptText("Choisir un combattant...");
        comboFighter.setMaxWidth(Double.MAX_VALUE);
        comboFighter.setStyle("-fx-font-size: 13px;");

        // Affichage du nom dans la combo
        comboFighter.setCellFactory(lv -> new ListCell<Fighter>() {
            @Override
            protected void updateItem(Fighter fighter, boolean empty) {
                super.updateItem(fighter, empty);
                if (empty || fighter == null) {
                    setText(null);
                } else {
                    setText(fighter.getName() + " (" + fighter.getRecord() + ")");
                }
            }
        });
        comboFighter.setButtonCell(new ListCell<Fighter>() {
            @Override
            protected void updateItem(Fighter fighter, boolean empty) {
                super.updateItem(fighter, empty);
                if (empty || fighter == null) {
                    setText("Choisir un combattant...");
                } else {
                    setText(fighter.getName() + " (" + fighter.getRecord() + ")");
                }
            }
        });

        // Bouton trouver meilleur adversaire
        Button btnFindOpponent = new Button("🎯 Trouver le Meilleur Adversaire");
        btnFindOpponent.setMaxWidth(Double.MAX_VALUE);
        btnFindOpponent.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; " +
                "-fx-font-size: 13px; -fx-padding: 12 20; -fx-cursor: hand; " +
                "-fx-font-weight: bold; -fx-background-radius: 5;");
        btnFindOpponent.setOnAction(e -> findBestOpponent());

        Separator sep2 = new Separator();

        // Carte résultat (cachée au départ)
        bestOpponentCard = createBestOpponentCard();
        bestOpponentCard.setVisible(false);
        bestOpponentCard.setManaged(false);

        panel.getChildren().addAll(
                panelTitle, panelSubtitle, sep1,
                lblSelect, comboFighter, btnFindOpponent,
                sep2, bestOpponentCard
        );

        return panel;
    }

    /**
     * Carte affichant le résultat du meilleur adversaire trouvé par l'IA
     */
    private VBox createBestOpponentCard() {
        VBox card = new VBox(10);
        card.setPadding(new Insets(15));
        card.setStyle("-fx-background-color: #eaf4fb; -fx-background-radius: 8; " +
                "-fx-border-color: #3498db; -fx-border-radius: 8; -fx-border-width: 1;");

        Label cardTitle = new Label("✅ Meilleur Adversaire Trouvé");
        cardTitle.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: #2980b9;");

        lblBestOpponent = new Label("");
        lblBestOpponent.setStyle("-fx-font-size: 12px; -fx-text-fill: #2c3e50;");
        lblBestOpponent.setWrapText(true);

        card.getChildren().addAll(cardTitle, lblBestOpponent);
        return card;
    }

    /**
     * Panneau droit : table des matchs + détails
     */
    private VBox createRightPanel() {
        VBox panel = new VBox(10);

        // Table
        table = createTable();
        VBox.setVgrow(table, Priority.ALWAYS);

        // Zone de détails
        VBox detailsContainer = createDetailsPanel();
        detailsContainer.setPrefHeight(180);
        detailsContainer.setMinHeight(150);

        panel.getChildren().addAll(table, detailsContainer);
        return panel;
    }

    private TableView<MatchProposal> createTable() {
        TableView<MatchProposal> table = new TableView<>();
        table.setItems(controller.getMatchProposals());
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<MatchProposal, String> colFighter1 = new TableColumn<>("Combattant 1");
        colFighter1.setCellValueFactory(cellData -> {
            try {
                return new javafx.beans.property.SimpleStringProperty(
                        cellData.getValue().getFighter1() != null ?
                                cellData.getValue().getFighter1().getFullName() : "N/A");
            } catch (Exception e) {
                return new javafx.beans.property.SimpleStringProperty("N/A");
            }
        });

        TableColumn<MatchProposal, String> colRecord1 = new TableColumn<>("Record");
        colRecord1.setCellValueFactory(cellData -> {
            try {
                return new javafx.beans.property.SimpleStringProperty(
                        cellData.getValue().getFighter1() != null ?
                                cellData.getValue().getFighter1().getRecord() : "N/A");
            } catch (Exception e) {
                return new javafx.beans.property.SimpleStringProperty("N/A");
            }
        });
        colRecord1.setStyle("-fx-alignment: CENTER;");
        colRecord1.setPrefWidth(90);

        TableColumn<MatchProposal, String> colVs = new TableColumn<>("VS");
        colVs.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty("⚔️"));
        colVs.setPrefWidth(50);
        colVs.setCellFactory(column -> new TableCell<MatchProposal, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); }
                else {
                    setText(item);
                    setStyle("-fx-font-size: 16px; -fx-alignment: CENTER; " +
                            "-fx-font-weight: bold; -fx-text-fill: #e74c3c;");
                }
            }
        });

        TableColumn<MatchProposal, String> colFighter2 = new TableColumn<>("Combattant 2");
        colFighter2.setCellValueFactory(cellData -> {
            try {
                return new javafx.beans.property.SimpleStringProperty(
                        cellData.getValue().getFighter2() != null ?
                                cellData.getValue().getFighter2().getFullName() : "N/A");
            } catch (Exception e) {
                return new javafx.beans.property.SimpleStringProperty("N/A");
            }
        });

        TableColumn<MatchProposal, String> colRecord2 = new TableColumn<>("Record");
        colRecord2.setCellValueFactory(cellData -> {
            try {
                return new javafx.beans.property.SimpleStringProperty(
                        cellData.getValue().getFighter2() != null ?
                                cellData.getValue().getFighter2().getRecord() : "N/A");
            } catch (Exception e) {
                return new javafx.beans.property.SimpleStringProperty("N/A");
            }
        });
        colRecord2.setStyle("-fx-alignment: CENTER;");
        colRecord2.setPrefWidth(90);

        TableColumn<MatchProposal, String> colScore = new TableColumn<>("Score AI");
        colScore.setCellValueFactory(cellData -> {
            try {
                return new javafx.beans.property.SimpleStringProperty(
                        String.format("%.1f/100", cellData.getValue().getMatchScore()));
            } catch (Exception e) {
                return new javafx.beans.property.SimpleStringProperty("0.0/100");
            }
        });
        colScore.setPrefWidth(100);
        colScore.setCellFactory(column -> new TableCell<MatchProposal, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); }
                else {
                    setText(item);
                    try {
                        double score = Double.parseDouble(item.split("/")[0]);
                        if (score >= 85)
                            setStyle("-fx-background-color: #2ecc71; -fx-text-fill: white; -fx-font-weight: bold; -fx-alignment: CENTER;");
                        else if (score >= 70)
                            setStyle("-fx-background-color: #f39c12; -fx-text-fill: white; -fx-font-weight: bold; -fx-alignment: CENTER;");
                        else
                            setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-weight: bold; -fx-alignment: CENTER;");
                    } catch (Exception e) { setStyle(""); }
                }
            }
        });

        table.getColumns().addAll(colFighter1, colRecord1, colVs, colFighter2, colRecord2, colScore);
        table.setStyle("-fx-background-color: white; -fx-font-size: 13px;");
        table.setPlaceholder(new Label("Aucun match généré.\nCliquez sur 'Générer tous les matchs' ou utilisez\nle panneau AI à gauche."));

        table.setRowFactory(tv -> {
            TableRow<MatchProposal> row = new TableRow<>();
            row.setOnMouseEntered(e -> { if (!row.isEmpty()) row.setStyle("-fx-background-color: #ecf0f1;"); });
            row.setOnMouseExited(e -> row.setStyle(""));
            return row;
        });

        table.getSelectionModel().selectedItemProperty().addListener((obs, old, newVal) -> {
            if (newVal != null) showMatchDetails(newVal);
        });

        controller.getMatchProposals().addListener(
                (javafx.collections.ListChangeListener<MatchProposal>) c -> updateMatchCount());

        return table;
    }

    private VBox createDetailsPanel() {
        VBox panel = new VBox(8);
        panel.setPadding(new Insets(12));
        panel.setStyle("-fx-background-color: white; -fx-border-color: #dfe6e9; -fx-border-width: 1;");

        Label title = new Label("📊 Détails du match sélectionné");
        title.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        txtDetails = new TextArea();
        txtDetails.setEditable(false);
        txtDetails.setWrapText(true);
        txtDetails.setStyle("-fx-font-size: 12px; -fx-font-family: 'Courier New', monospace; " +
                "-fx-background-color: #f8f9fa;");
        txtDetails.setText("Sélectionnez un match dans le tableau pour voir l'analyse détaillée...");
        VBox.setVgrow(txtDetails, Priority.ALWAYS);

        panel.getChildren().addAll(title, txtDetails);
        return panel;
    }

    /**
     * Trouve le meilleur adversaire pour le combattant sélectionné
     */
    private void findBestOpponent() {
        Fighter selectedFighter = comboFighter.getValue();

        if (selectedFighter == null) {
            showWarning("Aucun combattant sélectionné",
                    "Veuillez sélectionner un combattant dans la liste.");
            return;
        }

        try {
            System.out.println("🤖 Recherche du meilleur adversaire pour: " + selectedFighter.getName());

            MatchProposal bestMatch = controller.findBestOpponent(selectedFighter.getId());

            if (bestMatch == null || bestMatch.getFighter2() == null) {
                lblBestOpponent.setText("❌ Aucun adversaire compatible trouvé.\n" +
                        "Vérifiez qu'il y a d'autres combattants\ndans la même catégorie.");
                bestOpponentCard.setStyle("-fx-background-color: #fdecea; -fx-background-radius: 8; " +
                        "-fx-border-color: #e74c3c; -fx-border-radius: 8; -fx-border-width: 1;");
            } else {
                Fighter opponent = bestMatch.getFighter2();
                double score = bestMatch.getMatchScore();

                String emoji = score >= 85 ? "🟢" : score >= 70 ? "🟡" : "🔴";
                String quality = score >= 85 ? "Excellent" : score >= 70 ? "Bon" : "Acceptable";

                String text = "🥊 Adversaire : " + opponent.getName() + "\n" +
                        "📊 Record : " + opponent.getRecord() + "\n" +
                        "🏆 Win Rate : " + String.format("%.1f%%", opponent.getWinRate()) + "\n" +
                        "💪 Expérience : " + opponent.getExperience() + " combats\n\n" +
                        emoji + " Score AI : " + String.format("%.1f/100", score) + "\n" +
                        "📋 Qualité : " + quality;

                lblBestOpponent.setText(text);
                bestOpponentCard.setStyle("-fx-background-color: #eaf4fb; -fx-background-radius: 8; " +
                        "-fx-border-color: #3498db; -fx-border-radius: 8; -fx-border-width: 1;");

                // Afficher aussi les détails dans le panneau du bas
                showMatchDetails(bestMatch);
            }

            bestOpponentCard.setVisible(true);
            bestOpponentCard.setManaged(true);

        } catch (Exception e) {
            System.err.println("❌ Erreur lors de la recherche: " + e.getMessage());
            e.printStackTrace();
            showError("Erreur", "Impossible de trouver un adversaire: " + e.getMessage());
        }
    }

    private void generateMatches() {
        try {
            int maxMatches = spinnerMaxMatches.getValue();
            System.out.println("🎲 Génération de " + maxMatches + " matchs...");

            Platform.runLater(() -> {
                try {
                    controller.generateMatches(maxMatches);
                    if (controller.getMatchProposals().isEmpty()) {
                        showWarning("Aucun match",
                                "Impossible de générer des matchs.\n\n" +
                                "Vérifiez qu'il y a suffisamment de combattants " +
                                "dans des catégories compatibles.");
                    } else {
                        System.out.println("✓ " + controller.getMatchProposals().size() + " matchs générés");
                    }
                } catch (Exception e) {
                    showError("Erreur", "Impossible de générer les matchs: " + e.getMessage());
                } finally {
                    updateMatchCount();
                }
            });
        } catch (Exception e) {
            showError("Erreur", "Une erreur s'est produite lors de la génération.");
        }
    }

    private void clearMatches() {
        if (controller.getMatchProposals().isEmpty()) return;

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirmation");
        confirm.setHeaderText("Effacer les matchs");
        confirm.setContentText("Voulez-vous vraiment effacer tous les matchs générés ?");

        confirm.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                controller.getMatchProposals().clear();
                txtDetails.setText("Sélectionnez un match dans le tableau pour voir l'analyse détaillée...");
                bestOpponentCard.setVisible(false);
                bestOpponentCard.setManaged(false);
                updateMatchCount();
            }
        });
    }

    private void showMatchDetails(MatchProposal match) {
        if (match == null) return;
        try {
            StringBuilder d = new StringBuilder();
            
            d.append("         ANALYSE DU MATCH (AI)\n");
            

            if (match.getFighter1() != null && match.getFighter2() != null) {
                d.append("🥊 ").append(match.getFighter1().getFullName())
                        .append("  vs  ").append(match.getFighter2().getFullName()).append("\n\n");
                d.append("Combattant 1 : ").append(match.getFighter1().getRecord())
                        .append(" | WR: ").append(String.format("%.1f%%", match.getFighter1().getWinRate()))
                        .append(" | ").append(match.getFighter1().getExperience()).append(" combats\n");
                d.append("Combattant 2 : ").append(match.getFighter2().getRecord())
                        .append(" | WR: ").append(String.format("%.1f%%", match.getFighter2().getWinRate()))
                        .append(" | ").append(match.getFighter2().getExperience()).append(" combats\n\n");
            }

            d.append("📊 SCORE AI : ").append(String.format("%.1f/100", match.getMatchScore())).append("\n\n");

            if (match.getReasoning() != null && !match.getReasoning().isEmpty()) {
                d.append("💡 ANALYSE :\n").append(match.getReasoning());
            }

            txtDetails.setText(d.toString());
        } catch (Exception e) {
            txtDetails.setText("Erreur lors du chargement des détails.");
        }
    }

    private void updateMatchCount() {
        Platform.runLater(() -> {
            int count = controller.getMatchProposals().size();
            lblMatchCount.setText(count + " match" + (count > 1 ? "s" : "") +
                    " généré" + (count > 1 ? "s" : ""));
        });
    }

    public void refresh() {
        updateMatchCount();
        // Rafraîchir la liste des combattants dans la combo
        if (comboFighter != null) {
            comboFighter.setItems(controller.getFighters());
        }
    }

    public BorderPane getView() {
        return view;
    }

    private void showWarning(String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    private void showError(String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }
}