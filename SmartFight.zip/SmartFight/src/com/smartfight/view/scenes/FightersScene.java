package com.smartfight.view.scenes;

import com.smartfight.controller.MainController;
import com.smartfight.model.Fighter;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.time.LocalDate;

/**
 * Scène des combattants - CRUD complet
 * Create / Read / Update / Delete
 */
public class FightersScene {
    private MainController controller;
    private BorderPane view;
    private TableView<Fighter> table;
    private TextField txtSearch;
    private Label lblTotal;

    public FightersScene(MainController controller) {
        if (controller == null) {
            throw new IllegalArgumentException("Le contrôleur ne peut pas être null");
        }
        this.controller = controller;
        initializeUI();
    }

    private void initializeUI() {
        view = new BorderPane();
        view.setPadding(new Insets(30));
        view.setStyle("-fx-background-color: #f5f5f5;");

        VBox header = createHeader();
        view.setTop(header);

        table = createTable();
        VBox tableContainer = new VBox(table);
        tableContainer.setPadding(new Insets(20, 0, 0, 0));
        VBox.setVgrow(table, Priority.ALWAYS);
        view.setCenter(tableContainer);
    }

    private VBox createHeader() {
        VBox header = new VBox(15);

        Label title = new Label("🥋 Combattants");
        title.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        Label subtitle = new Label("Gestion et visualisation des combattants");
        subtitle.setStyle("-fx-font-size: 14px; -fx-text-fill: #7f8c8d;");

        // ── Barre de recherche ──
        HBox searchBar = new HBox(15);
        searchBar.setAlignment(Pos.CENTER_LEFT);

        txtSearch = new TextField();
        txtSearch.setPromptText("🔍 Rechercher par nom ou nationalité...");
        txtSearch.setPrefWidth(350);
        txtSearch.setStyle("-fx-font-size: 14px; -fx-padding: 10; -fx-background-radius: 5;");
        txtSearch.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && newVal.length() >= 2) searchFighters();
            else if (newVal.isEmpty()) refresh();
        });

        Button btnSearch = new Button("Rechercher");
        btnSearch.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; " +
                "-fx-font-size: 14px; -fx-padding: 10 20; -fx-cursor: hand; -fx-background-radius: 5;");
        btnSearch.setOnAction(e -> searchFighters());

        Button btnRefresh = new Button("🔄 Actualiser");
        btnRefresh.setStyle("-fx-background-color: #2ecc71; -fx-text-fill: white; " +
                "-fx-font-size: 14px; -fx-padding: 10 20; -fx-cursor: hand; -fx-background-radius: 5;");
        btnRefresh.setOnAction(e -> refresh());

        Region spacer1 = new Region();
        HBox.setHgrow(spacer1, Priority.ALWAYS);

        lblTotal = new Label("Total: 0");
        lblTotal.setStyle("-fx-font-size: 14px; -fx-text-fill: #7f8c8d; -fx-font-weight: bold;");

        searchBar.getChildren().addAll(txtSearch, btnSearch, btnRefresh, spacer1, lblTotal);

        // ── Barre CRUD ──
        HBox crudBar = new HBox(10);
        crudBar.setAlignment(Pos.CENTER_LEFT);

        Button btnAdd = new Button("➕ Ajouter");
        btnAdd.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; " +
                "-fx-font-size: 13px; -fx-padding: 9 18; -fx-cursor: hand; " +
                "-fx-font-weight: bold; -fx-background-radius: 5;");
        btnAdd.setOnAction(e -> showAddDialog());

        Button btnEdit = new Button("✏️ Modifier");
        btnEdit.setStyle("-fx-background-color: #f39c12; -fx-text-fill: white; " +
                "-fx-font-size: 13px; -fx-padding: 9 18; -fx-cursor: hand; " +
                "-fx-font-weight: bold; -fx-background-radius: 5;");
        btnEdit.setOnAction(e -> {
            Fighter selected = table.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showWarning("Aucune sélection", "Veuillez sélectionner un combattant à modifier.");
            } else {
                showEditDialog(selected);
            }
        });

        Button btnDelete = new Button("🗑️ Supprimer");
        btnDelete.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; " +
                "-fx-font-size: 13px; -fx-padding: 9 18; -fx-cursor: hand; " +
                "-fx-font-weight: bold; -fx-background-radius: 5;");
        btnDelete.setOnAction(e -> {
            Fighter selected = table.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showWarning("Aucune sélection", "Veuillez sélectionner un combattant à supprimer.");
            } else {
                confirmDelete(selected);
            }
        });

        Label crudHint = new Label("💡 Double-clic sur une ligne pour voir les détails");
        crudHint.setStyle("-fx-font-size: 12px; -fx-text-fill: #95a5a6;");

        Region spacer2 = new Region();
        HBox.setHgrow(spacer2, Priority.ALWAYS);

        crudBar.getChildren().addAll(btnAdd, btnEdit, btnDelete, spacer2, crudHint);

        header.getChildren().addAll(title, subtitle, searchBar, crudBar);
        return header;
    }

    private TableView<Fighter> createTable() {
        TableView<Fighter> table = new TableView<>();
        table.setItems(controller.getFighters());
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Colonne #
        TableColumn<Fighter, Integer> colId = new TableColumn<>("#");
        colId.setCellFactory(column -> new TableCell<Fighter, Integer>() {
            @Override
            protected void updateItem(Integer item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? null : String.valueOf(getIndex() + 1));
            }
        });
        colId.setPrefWidth(50);
        colId.setStyle("-fx-alignment: CENTER;");

        // Colonne Nickname
        TableColumn<Fighter, String> colName = new TableColumn<>("Nickname");
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colName.setPrefWidth(140);

        // Colonne Nationalité
        TableColumn<Fighter, String> colNationality = new TableColumn<>("Nationalité");
        colNationality.setCellValueFactory(new PropertyValueFactory<>("nationality"));
        colNationality.setPrefWidth(100);
        colNationality.setStyle("-fx-alignment: CENTER;");

        // ✅ Colonne Weight Class (NOUVEAU)
        TableColumn<Fighter, String> colWeightClass = new TableColumn<>("Weight Class");
        colWeightClass.setCellValueFactory(cellData -> {
            int id = cellData.getValue().getWeightClassId();
            return new javafx.beans.property.SimpleStringProperty(mapIdToWeightClass(id));
        });
        colWeightClass.setPrefWidth(130);
        colWeightClass.setStyle("-fx-alignment: CENTER;");

        // Colonne Record
        TableColumn<Fighter, String> colRecord = new TableColumn<>("Record (W-L-D)");
        colRecord.setCellValueFactory(cellData -> {
            try {
                return new javafx.beans.property.SimpleStringProperty(cellData.getValue().getRecord());
            } catch (Exception e) {
                return new javafx.beans.property.SimpleStringProperty("0-0-0");
            }
        });
        colRecord.setPrefWidth(120);
        colRecord.setStyle("-fx-alignment: CENTER;");

        // Colonne Taux de victoire
        TableColumn<Fighter, String> colWinRate = new TableColumn<>("Taux de victoire");
        colWinRate.setCellValueFactory(cellData -> {
            try {
                return new javafx.beans.property.SimpleStringProperty(
                        String.format("%.1f%%", cellData.getValue().getWinRate()));
            } catch (Exception e) {
                return new javafx.beans.property.SimpleStringProperty("0.0%");
            }
        });
        colWinRate.setPrefWidth(120);
        colWinRate.setStyle("-fx-alignment: CENTER;");
        colWinRate.setCellFactory(column -> new TableCell<Fighter, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); }
                else {
                    setText(item);
                    try {
                        double rate = Double.parseDouble(item.replace("%", ""));
                        if (rate >= 70) setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold;");
                        else if (rate >= 50) setStyle("-fx-text-fill: #f39c12; -fx-font-weight: bold;");
                        else setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
                    } catch (Exception e) { setStyle(""); }
                }
            }
        });

        // Colonne Combats
        TableColumn<Fighter, Integer> colExperience = new TableColumn<>("Combats");
        colExperience.setCellValueFactory(new PropertyValueFactory<>("experience"));
        colExperience.setPrefWidth(80);
        colExperience.setStyle("-fx-alignment: CENTER;");

        // ✅ Ajout de colWeightClass dans le tableau
        table.getColumns().addAll(colId, colName, colNationality, colWeightClass, colRecord, colWinRate, colExperience);
        table.setStyle("-fx-background-color: white; -fx-font-size: 13px;");
        table.setPlaceholder(new Label("Aucun combattant trouvé. Cliquez sur '➕ Ajouter' pour commencer."));

        table.setRowFactory(tv -> {
            TableRow<Fighter> row = new TableRow<>();
            row.setOnMouseEntered(e -> { if (!row.isEmpty()) row.setStyle("-fx-background-color: #ecf0f1;"); });
            row.setOnMouseExited(e -> row.setStyle(""));
            row.setOnMouseClicked(e -> {
                if (e.getClickCount() == 2 && !row.isEmpty()) showFighterDetails(row.getItem());
            });
            return row;
        });

        controller.getFighters().addListener(
                (javafx.collections.ListChangeListener<Fighter>) c -> updateTotal());

        return table;
    }

    // ═══════════════════════════════════════════
    //   CRUD DIALOGS
    // ═══════════════════════════════════════════

    private void showAddDialog() {
        Dialog<Fighter> dialog = new Dialog<>();
        dialog.setTitle("➕ Ajouter un combattant");
        dialog.setHeaderText("Remplissez les informations du nouveau combattant");

        ButtonType btnSave = new ButtonType("💾 Enregistrer", ButtonBar.ButtonData.OK_DONE);
        ButtonType btnCancel = new ButtonType("Annuler", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(btnSave, btnCancel);

        // ✅ On stocke le ComboBox dans un tableau pour y accéder dans le lambda
        ComboBox<String>[] cmbRef = new ComboBox[1];
        GridPane grid = createFighterForm(null, cmbRef);
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().setPrefWidth(480);

        dialog.setResultConverter(btn -> {
            if (btn == btnSave) {
                return extractFighterFromForm(grid, new Fighter(), cmbRef[0]);
            }
            return null;
        });

        dialog.showAndWait().ifPresent(fighter -> {
            if (fighter != null && fighter.getName() != null && !fighter.getName().isEmpty()) {
                boolean success = controller.saveFighter(fighter);
                if (success) {
                    showSuccess("Combattant ajouté avec succès !");
                    refresh();
                } else {
                    showError("Erreur", "Impossible d'ajouter le combattant.");
                }
            } else {
                showWarning("Données invalides", "Le nickname est obligatoire.");
            }
        });
    }

    private void showEditDialog(Fighter fighter) {
        Dialog<Fighter> dialog = new Dialog<>();
        dialog.setTitle("✏️ Modifier le combattant");
        dialog.setHeaderText("Modifier : " + fighter.getName());

        ButtonType btnSave = new ButtonType("💾 Enregistrer", ButtonBar.ButtonData.OK_DONE);
        ButtonType btnCancel = new ButtonType("Annuler", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(btnSave, btnCancel);

        ComboBox<String>[] cmbRef = new ComboBox[1];
        GridPane grid = createFighterForm(fighter, cmbRef);
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().setPrefWidth(480);

        dialog.setResultConverter(btn -> {
            if (btn == btnSave) {
                return extractFighterFromForm(grid, fighter, cmbRef[0]);
            }
            return null;
        });

        dialog.showAndWait().ifPresent(updatedFighter -> {
            if (updatedFighter != null) {
                boolean success = controller.saveFighter(updatedFighter);
                if (success) {
                    showSuccess("Combattant modifié avec succès !");
                    refresh();
                } else {
                    showError("Erreur", "Impossible de modifier le combattant.");
                }
            }
        });
    }

    private void confirmDelete(Fighter fighter) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("🗑️ Supprimer");
        confirm.setHeaderText("Supprimer : " + fighter.getName() + " ?");
        confirm.setContentText("Cette action est irréversible.\n" +
                "Record : " + fighter.getRecord() + "\n" +
                "Voulez-vous vraiment supprimer ce combattant ?");

        confirm.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                boolean success = controller.deleteFighter(fighter.getId());
                if (success) {
                    showSuccess("Combattant supprimé avec succès !");
                    refresh();
                } else {
                    showError("Erreur", "Impossible de supprimer le combattant.");
                }
            }
        });
    }

    /**
     * ✅ Formulaire avec Weight Class ComboBox
     * Le ComboBox est passé via cmbRef[0] pour éviter les problèmes de lookup JavaFX
     */
    private GridPane createFighterForm(Fighter fighter, ComboBox<String>[] cmbRef) {
        GridPane grid = new GridPane();
        grid.setHgap(15);
        grid.setVgap(12);
        grid.setPadding(new Insets(20));

        String labelStyle = "-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: #34495e;";
        String fieldStyle = "-fx-font-size: 13px; -fx-padding: 8; -fx-background-radius: 4;";

        // Nickname
        Label lblNick = new Label("Nickname * :");
        lblNick.setStyle(labelStyle);
        TextField txtNick = new TextField(fighter != null ? fighter.getName() : "");
        txtNick.setPromptText("Ex: The Lion");
        txtNick.setStyle(fieldStyle);
        txtNick.setPrefWidth(280);
        txtNick.setId("nickname");

        // Nationalité
        Label lblNat = new Label("Nationalité :");
        lblNat.setStyle(labelStyle);
        TextField txtNat = new TextField(fighter != null ? fighter.getNationality() : "");
        txtNat.setPromptText("Ex: Tunisian");
        txtNat.setStyle(fieldStyle);
        txtNat.setId("nationality");

        // Wins
        Label lblWins = new Label("Victoires (W) :");
        lblWins.setStyle(labelStyle);
        TextField txtWins = new TextField(fighter != null ? String.valueOf(fighter.getWins()) : "0");
        txtWins.setPromptText("0");
        txtWins.setStyle(fieldStyle);
        txtWins.setId("wins");

        // Losses
        Label lblLoss = new Label("Défaites (L) :");
        lblLoss.setStyle(labelStyle);
        TextField txtLoss = new TextField(fighter != null ? String.valueOf(fighter.getLosses()) : "0");
        txtLoss.setPromptText("0");
        txtLoss.setStyle(fieldStyle);
        txtLoss.setId("losses");

        // Draws
        Label lblDraw = new Label("Nuls (D) :");
        lblDraw.setStyle(labelStyle);
        TextField txtDraw = new TextField(fighter != null ? String.valueOf(fighter.getDraws()) : "0");
        txtDraw.setPromptText("0");
        txtDraw.setStyle(fieldStyle);
        txtDraw.setId("draws");

        // ✅ Weight Class ComboBox
        Label lblWeightClass = new Label("Weight Class :");
        lblWeightClass.setStyle(labelStyle);
        ComboBox<String> cmbWeightClass = new ComboBox<>();
        cmbWeightClass.getItems().addAll(
            "Flyweight",      // ID 1
            "Featherweight",  // ID 2
            "Lightweight",    // ID 3
            "Welterweight",   // ID 4
            "Middleweight",   // ID 5
            "Heavyweight"     // ID 6
        );
        cmbWeightClass.setPrefWidth(280);
        cmbWeightClass.setStyle(fieldStyle);
        // Pré-remplir si modification
        if (fighter != null && fighter.getWeightClassId() > 0) {
            cmbWeightClass.setValue(mapIdToWeightClass(fighter.getWeightClassId()));
        } else {
            cmbWeightClass.setValue("Flyweight");
        }
        // ✅ Stocker la référence dans le tableau pour y accéder dans le lambda
        cmbRef[0] = cmbWeightClass;

        // Date de naissance
        Label lblDob = new Label("Date de naissance :");
        lblDob.setStyle(labelStyle);
        DatePicker datePicker = new DatePicker();
        datePicker.setId("dob");
        if (fighter != null && fighter.getDateOfBirth() != null) {
            datePicker.setValue(fighter.getDateOfBirth());
        } else {
            datePicker.setValue(LocalDate.of(1995, 1, 1));
        }
        datePicker.setStyle(fieldStyle);

        // Placement dans la grille
        grid.add(lblNick,        0, 0); grid.add(txtNick,       1, 0);
        grid.add(lblNat,         0, 1); grid.add(txtNat,        1, 1);
        grid.add(lblWins,        0, 2); grid.add(txtWins,       1, 2);
        grid.add(lblLoss,        0, 3); grid.add(txtLoss,       1, 3);
        grid.add(lblDraw,        0, 4); grid.add(txtDraw,       1, 4);
        grid.add(lblWeightClass, 0, 5); grid.add(cmbWeightClass,1, 5); // ✅
        grid.add(lblDob,         0, 6); grid.add(datePicker,    1, 6);

        return grid;
    }

    /**
     * ✅ Extraction du formulaire avec le ComboBox passé directement
     */
    private Fighter extractFighterFromForm(GridPane grid, Fighter fighter, ComboBox<String> cmbWeightClass) {
        try {
            TextField txtNick     = (TextField)  grid.lookup("#nickname");
            TextField txtNat      = (TextField)  grid.lookup("#nationality");
            TextField txtWins     = (TextField)  grid.lookup("#wins");
            TextField txtLoss     = (TextField)  grid.lookup("#losses");
            TextField txtDraw     = (TextField)  grid.lookup("#draws");
            DatePicker datePicker = (DatePicker) grid.lookup("#dob");

            fighter.setName(txtNick.getText().trim());
            fighter.setNationality(txtNat.getText().trim());
            fighter.setWins(Integer.parseInt(txtWins.getText().trim().isEmpty() ? "0" : txtWins.getText().trim()));
            fighter.setLosses(Integer.parseInt(txtLoss.getText().trim().isEmpty() ? "0" : txtLoss.getText().trim()));
            fighter.setDraws(Integer.parseInt(txtDraw.getText().trim().isEmpty() ? "0" : txtDraw.getText().trim()));

            if (datePicker.getValue() != null) {
                fighter.setDateOfBirth(datePicker.getValue());
            }

            // ✅ Weight Class directement depuis la référence
            if (cmbWeightClass != null && cmbWeightClass.getValue() != null) {
                fighter.setWeightClassId(mapWeightClassToId(cmbWeightClass.getValue()));
            }

            return fighter;

        } catch (NumberFormatException e) {
            showWarning("Données invalides", "Les champs W, L, D doivent être des nombres entiers.");
            return null;
        }
    }

    // ═══════════════════════════════════════════
    //   MAPPING WEIGHT CLASS ↔ ID
    // ═══════════════════════════════════════════

    private String mapIdToWeightClass(int id) {
        switch (id) {
            case 1: return "Flyweight";
            case 2: return "Featherweight";
            case 3: return "Lightweight";
            case 4: return "Welterweight";
            case 5: return "Middleweight";
            case 6: return "Heavyweight";
            default: return "Unknown";
        }
    }

    private int mapWeightClassToId(String name) {
        switch (name) {
            case "Flyweight":     return 1;
            case "Featherweight": return 2;
            case "Lightweight":   return 3;
            case "Welterweight":  return 4;
            case "Middleweight":  return 5;
            case "Heavyweight":   return 6;
            default: return 0;
        }
    }

    // ═══════════════════════════════════════════
    //   MÉTHODES UTILITAIRES
    // ═══════════════════════════════════════════

    private void showFighterDetails(Fighter fighter) {
        if (fighter == null) return;
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Détails du combattant");
        alert.setHeaderText(fighter.getFullName());

        StringBuilder d = new StringBuilder();
        d.append("ID          : ").append(fighter.getId()).append("\n");
        d.append("Nickname    : ").append(fighter.getName()).append("\n");
        d.append("Naissance   : ").append(fighter.getDateOfBirth()).append("\n");
        d.append("Nationalité : ").append(fighter.getNationality()).append("\n");
        d.append("Weight Class: ").append(mapIdToWeightClass(fighter.getWeightClassId())).append("\n");
        d.append("Record      : ").append(fighter.getRecord()).append("\n");
        d.append("Win Rate    : ").append(String.format("%.1f%%", fighter.getWinRate())).append("\n");
        d.append("Expérience  : ").append(fighter.getExperience()).append(" combats\n");

        alert.setContentText(d.toString());
        alert.showAndWait();
    }

    private void searchFighters() {
        try {
            String term = txtSearch.getText().trim();
            if (term.isEmpty()) { refresh(); return; }
            controller.searchFighters(term);
            updateTotal();
        } catch (Exception e) {
            showError("Erreur de recherche", "Impossible d'effectuer la recherche.");
        }
    }

    private void updateTotal() {
        Platform.runLater(() -> {
            int total = controller.getFighters().size();
            lblTotal.setText("Total: " + total + " combattant" + (total > 1 ? "s" : ""));
        });
    }

    public void refresh() {
        try {
            controller.loadAllFighters();
            txtSearch.clear();
            updateTotal();
        } catch (Exception e) {
            showError("Erreur", "Impossible de charger les combattants.");
        }
    }

    public BorderPane getView() { return view; }

    private void showSuccess(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("✅ Succès");
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    private void showWarning(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }
}