package com.smartfight.view.scenes;

import com.smartfight.controller.MainController;
import com.smartfight.service.SmartFightService.SmartFightStats;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

/**
 * Scène Dashboard - Vue d'ensemble de l'application
 * VERSION CORRIGÉE - Gestion améliorée des erreurs et animations
 */
public class DashboardScene {
    private MainController controller;
    private BorderPane view;
    
    // Labels pour les statistiques
    private Label lblTotalFighters;
    private Label lblTotalRankings;
    private Label lblTotalWins;
    private Label lblTotalMatches;
    
    public DashboardScene(MainController controller) {
        if (controller == null) {
            throw new IllegalArgumentException("Le contrôleur ne peut pas être null");
        }
        this.controller = controller;
        initializeUI();
    }
    
    private void initializeUI() {
        view = new BorderPane();
        view.setPadding(new Insets(30));
        view.setStyle("-fx-background-color: #f5f5f5;");
        
        // Titre
        Label title = new Label("📊 Dashboard");
        title.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        Label subtitle = new Label("Vue d'ensemble du système SmartFight");
        subtitle.setStyle("-fx-font-size: 14px; -fx-text-fill: #7f8c8d; -fx-padding: 5 0 0 0;");
        
        VBox header = new VBox(5, title, subtitle);
        header.setPadding(new Insets(0, 0, 30, 0));
        
        // Cartes de statistiques
        HBox statsBox = new HBox(20);
        statsBox.setAlignment(Pos.CENTER);
        
        // Initialiser les labels
        lblTotalFighters = new Label("0");
        lblTotalRankings = new Label("0");
        lblTotalWins = new Label("0");
        lblTotalMatches = new Label("0");
        
        VBox card1 = createStatCard("👤 Combattants", lblTotalFighters, "#3498db");
        VBox card2 = createStatCard("🏆 Classements", lblTotalRankings, "#2ecc71");
        VBox card3 = createStatCard("✅ Victoires Totales", lblTotalWins, "#e74c3c");
        VBox card4 = createStatCard("⚔️ Matchs Générés", lblTotalMatches, "#f39c12");
        
        statsBox.getChildren().addAll(card1, card2, card3, card4);
        
        // Section d'informations
        VBox infoSection = createInfoSection();
        
        // Section de bienvenue
        VBox welcomeSection = createWelcomeSection();
        
        VBox content = new VBox(30, header, statsBox, infoSection, welcomeSection);
        view.setCenter(content);
        
        // Charger les statistiques initiales
        refresh();
    }
    
    /**
     * Crée une carte de statistique stylée
     */
    private VBox createStatCard(String title, Label valueLabel, String color) {
        VBox card = new VBox(15);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(30));
        card.setPrefSize(250, 150);
        card.setStyle("-fx-background-color: white; " +
                     "-fx-background-radius: 10; " +
                     "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 2);");
        
        // Effet hover
        card.setOnMouseEntered(e -> {
            card.setStyle("-fx-background-color: white; " +
                         "-fx-background-radius: 10; " +
                         "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 15, 0, 0, 3); " +
                         "-fx-scale-x: 1.02; -fx-scale-y: 1.02;");
        });
        
        card.setOnMouseExited(e -> {
            card.setStyle("-fx-background-color: white; " +
                         "-fx-background-radius: 10; " +
                         "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 2);");
        });
        
        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #7f8c8d; -fx-font-weight: bold;");
        
        valueLabel.setStyle("-fx-font-size: 42px; -fx-font-weight: bold; -fx-text-fill: " + color + ";");
        
        card.getChildren().addAll(titleLabel, valueLabel);
        
        return card;
    }
    
    /**
     * Crée la section d'informations sur le système
     */
    private VBox createInfoSection() {
        VBox section = new VBox(20);
        section.setPadding(new Insets(20));
        section.setStyle("-fx-background-color: white; " +
                        "-fx-background-radius: 10; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 2);");
        
        Label infoTitle = new Label("📚 Fonctionnalités du Système");
        infoTitle.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        Label info1 = new Label("✓ Matchmaking intelligent basé sur l'expérience, taux de victoire et classement");
        Label info2 = new Label("✓ Algorithme de classement dynamique (ELO modifié)");
        
        
        for (Label lbl : new Label[]{info1, info2}) {
            lbl.setStyle("-fx-font-size: 14px; -fx-text-fill: #34495e; -fx-padding: 5 0 0 20;");
            lbl.setWrapText(true);
        }
        
        section.getChildren().addAll(infoTitle, info1, info2);
        
        return section;
    }
    
    /**
     * Crée une section de bienvenue
     */
    private VBox createWelcomeSection() {
        VBox section = new VBox(15);
        section.setPadding(new Insets(20));
        section.setStyle("-fx-background-color: linear-gradient(to right, #667eea, #764ba2); " +
                        "-fx-background-radius: 10; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 2);");
        
        Label welcomeTitle = new Label("💡 Guide de Démarrage Rapide");
        welcomeTitle.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: white;");
        
        Label step1 = new Label("1. 🥋 Consultez la liste des combattants dans l'onglet 'Combattants'");
        Label step2 = new Label("2. ⚔️ Générez des matchs dans l'onglet 'Matchmaking'");
        Label step3 = new Label("3. 🏆 Visualisez les classements dans l'onglet 'Classements'");
        
        for (Label lbl : new Label[]{step1, step2, step3}) {
            lbl.setStyle("-fx-font-size: 14px; -fx-text-fill: white; -fx-padding: 5 0 0 10;");
            lbl.setWrapText(true);
        }
        
        Label usage = new Label("👈 Utilisez la navigation à gauche pour accéder aux différentes sections");
        usage.setStyle("-fx-font-size: 13px; -fx-text-fill: #e0e0e0; -fx-padding: 10 0 0 0; " +
                      "-fx-font-style: italic;");
        
        section.getChildren().addAll(welcomeTitle, step1, step2, step3, usage);
        
        return section;
    }
    
    /**
     * Rafraîchit les statistiques affichées
     */
    public void refresh() {
        try {
            System.out.println("🔄 Rafraîchissement du Dashboard...");
            
            // Récupérer les stats de manière asynchrone pour ne pas bloquer l'UI
            Platform.runLater(() -> {
                try {
                    SmartFightStats stats = controller.getStats();
                    
                    if (stats != null) {
                        // Animer le changement des valeurs
                        animateValue(lblTotalFighters, stats.totalFighters);
                        animateValue(lblTotalRankings, stats.totalRankings);
                        animateValue(lblTotalWins, stats.totalWins);
                        animateValue(lblTotalMatches, stats.totalMatchProposals);
                        
                        System.out.println("✓ Dashboard rafraîchi - " + 
                                         stats.totalFighters + " combattants, " +
                                         stats.totalRankings + " classements");
                    } else {
                        System.err.println("⚠️ Stats null retournées");
                        setDefaultValues();
                    }
                } catch (Exception e) {
                    System.err.println("❌ Erreur lors du rafraîchissement: " + e.getMessage());
                    e.printStackTrace();
                    setDefaultValues();
                }
            });
            
        } catch (Exception e) {
            System.err.println("❌ Erreur dans refresh(): " + e.getMessage());
            e.printStackTrace();
            setDefaultValues();
        }
    }
    
    /**
     * Anime le changement de valeur d'un label
     */
    private void animateValue(Label label, int targetValue) {
        try {
            // Pour l'instant, mise à jour simple
            // Dans une version future, on pourrait ajouter une vraie animation
            label.setText(String.valueOf(targetValue));
        } catch (Exception e) {
            System.err.println("⚠️ Erreur lors de l'animation: " + e.getMessage());
            label.setText("0");
        }
    }
    
    /**
     * Définit les valeurs par défaut en cas d'erreur
     */
    private void setDefaultValues() {
        Platform.runLater(() -> {
            lblTotalFighters.setText("0");
            lblTotalRankings.setText("0");
            lblTotalWins.setText("0");
            lblTotalMatches.setText("0");
        });
    }
    
    /**
     * Retourne la vue du Dashboard
     */
    public BorderPane getView() {
        return view;
    }
}
