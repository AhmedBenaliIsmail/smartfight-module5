package com.smartfight.view.scenes;

import com.smartfight.controller.MainController;
import com.smartfight.model.Ranking;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

public class RankingsScene {
    private MainController controller;
    private BorderPane view;
    private TableView<Ranking> table;
    private BarChart<String, Number> chart;
    private ComboBox<String> cmbWeightClass;
    private Label lblRankingCount;
    private TextField txtSearch;

    public RankingsScene(MainController controller) {
        if (controller == null) {
            throw new IllegalArgumentException("Le contrôleur ne peut pas être null");
        }
        this.controller = controller;
        initializeUI();
    }

    private void initializeUI() {
        view = new BorderPane();
        view.setPadding(new Insets(30));
        view.setStyle("-fx-background-color: #f5f5f5;");

        VBox header = createHeader();
        view.setTop(header);

        SplitPane splitPane = new SplitPane();
        splitPane.setOrientation(javafx.geometry.Orientation.HORIZONTAL);
        splitPane.setDividerPositions(0.6);

        table = createTable();
        VBox tableContainer = new VBox(10);
        tableContainer.setPadding(new Insets(20, 0, 0, 0));
        VBox.setVgrow(table, Priority.ALWAYS);
        tableContainer.getChildren().add(table);

        VBox chartContainer = createChartPanel();

        splitPane.getItems().addAll(tableContainer, chartContainer);
        view.setCenter(splitPane);
    }

    private VBox createHeader() {
        VBox header = new VBox(15);

        Label title = new Label("🏆 Classements");
        title.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        Label subtitle = new Label("Rankings dynamiques basés sur les performances");
        subtitle.setStyle("-fx-font-size: 14px; -fx-text-fill: #7f8c8d;");

        HBox actionBar = new HBox(15);
        actionBar.setAlignment(Pos.CENTER_LEFT);

        Label lblWeightClass = new Label("Discipline:");
        lblWeightClass.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        cmbWeightClass = new ComboBox<>();
        // ✅ Noms EXACTS de ta table discipline
        cmbWeightClass.getItems().addAll(
            "All",        // Toutes
            "Boxing",     // ID 1 → Heavyweight
            "MMA",        // ID 2 → Lightweight
            "Judo",       // ID 3 → Open
            "Kickboxing", // ID 4 → Middleweight
            "Wrestling"   // ID 5 → Welterweight
        );
        cmbWeightClass.setValue("All");
        cmbWeightClass.setPrefWidth(200);

        Button btnFilter = new Button("Filtrer");
        btnFilter.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; " +
                "-fx-font-size: 13px; -fx-padding: 9 18; -fx-cursor: hand; -fx-background-radius: 5;");
        btnFilter.setOnAction(e -> filterRankings());

        Button btnRecalculate = new Button("♻️ Recalculer");
        btnRecalculate.setStyle("-fx-background-color: #f39c12; -fx-text-fill: white; " +
                "-fx-font-size: 13px; -fx-padding: 9 18; -fx-cursor: hand; -fx-background-radius: 5;");
        btnRecalculate.setOnAction(e -> recalculateRankings());

        Button btnRefresh = new Button("🔄 Actualiser");
        btnRefresh.setStyle("-fx-background-color: #2ecc71; -fx-text-fill: white; " +
                "-fx-font-size: 13px; -fx-padding: 9 18; -fx-cursor: hand; -fx-background-radius: 5;");
        btnRefresh.setOnAction(e -> refresh());

        txtSearch = new TextField();
        txtSearch.setPromptText("Rechercher un combattant...");
        txtSearch.setPrefWidth(200);
        txtSearch.textProperty().addListener((obs, oldVal, newVal) -> filterByName(newVal));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        lblRankingCount = new Label("0 classement");
        lblRankingCount.setStyle("-fx-font-size: 14px; -fx-text-fill: #7f8c8d; -fx-font-weight: bold;");

        actionBar.getChildren().addAll(
            lblWeightClass, cmbWeightClass, btnFilter,
            btnRecalculate, btnRefresh, txtSearch, spacer, lblRankingCount
        );

        header.getChildren().addAll(title, subtitle, actionBar);
        return header;
    }

    private TableView<Ranking> createTable() {
        TableView<Ranking> table = new TableView<>();
        table.setItems(controller.getRankings());
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.setStyle("-fx-background-color: white; -fx-font-size: 13px;");

        // Colonne Rang
        TableColumn<Ranking, Integer> colRank = new TableColumn<>("Rang");
        colRank.setCellValueFactory(new PropertyValueFactory<>("rank"));
        colRank.setStyle("-fx-alignment: CENTER;");
        colRank.setPrefWidth(70);

        // Colonne Combattant
        TableColumn<Ranking, String> colName = new TableColumn<>("Combattant");
        colName.setCellValueFactory(cellData ->
            new javafx.beans.property.SimpleStringProperty(
                cellData.getValue().getFighterName() != null ? cellData.getValue().getFighterName() : "N/A"
            )
        );
        colName.setPrefWidth(180);

        // Colonne Score
        TableColumn<Ranking, String> colScore = new TableColumn<>("Score");
        colScore.setCellValueFactory(cellData ->
            new javafx.beans.property.SimpleStringProperty(
                String.format("%.1f", cellData.getValue().getScore())
            )
        );
        colScore.setStyle("-fx-alignment: CENTER;");
        colScore.setPrefWidth(100);

        // ✅ Colonne Discipline — utilise le nom retourné directement par la DB (weight_class_name)
        // qui correspond au champ "name" de la table discipline (Boxing, MMA, Judo...)
        TableColumn<Ranking, String> colDiscipline = new TableColumn<>("Discipline");
        colDiscipline.setCellValueFactory(cellData ->
            new javafx.beans.property.SimpleStringProperty(
                mapDisciplineIdToName(cellData.getValue().getWeightClassId())
            )
        );
        colDiscipline.setStyle("-fx-alignment: CENTER;");
        colDiscipline.setPrefWidth(140);

        table.getColumns().addAll(colRank, colName, colScore, colDiscipline);
        table.setPlaceholder(new Label("Aucun classement. Cliquez sur '♻️ Recalculer' pour générer."));

        table.setRowFactory(tv -> {
            TableRow<Ranking> row = new TableRow<>();
            row.setOnMouseEntered(e -> { if (!row.isEmpty()) row.setStyle("-fx-background-color: #ecf0f1;"); });
            row.setOnMouseExited(e -> row.setStyle(""));
            return row;
        });

        controller.getRankings().addListener((javafx.collections.ListChangeListener<Ranking>) c -> {
            updateRankingCount();
            updateChart();
        });

        return table;
    }

    private VBox createChartPanel() {
        VBox panel = new VBox(10);
        panel.setPadding(new Insets(20, 10, 10, 10));
        panel.setStyle("-fx-background-color: white;");

        Label title = new Label("📊 Top 10 des Classements");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Combattant");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Score");

        chart = new BarChart<>(xAxis, yAxis);
        chart.setLegendVisible(false);
        chart.setAnimated(true);
        VBox.setVgrow(chart, Priority.ALWAYS);

        panel.getChildren().addAll(title, chart);
        return panel;
    }

    private void updateChart() {
        Platform.runLater(() -> {
            chart.getData().clear();
            XYChart.Series<String, Number> series = new XYChart.Series<>();
            int count = 0;
            for (Ranking ranking : controller.getRankings()) {
                if (count >= 10) break;
                series.getData().add(new XYChart.Data<>(
                    ranking.getFighterName() != null ? ranking.getFighterName() : "N/A",
                    ranking.getScore()
                ));
                count++;
            }
            chart.getData().add(series);
        });
    }

    private void filterRankings() {
        String selected = cmbWeightClass.getValue();
        if (selected == null || selected.equals("All")) {
            controller.loadAllRankings();
        } else {
            // ✅ Convertit le nom de discipline en ID correct
            int id = mapDisciplineNameToId(selected);
            if (id > 0) {
                controller.loadRankingsByWeightClass(id);
            } else {
                controller.loadAllRankings();
            }
        }
    }

    private void filterByName(String name) {
        controller.filterRankingsByName(name);
        updateChart();
    }

    // ✅ ID → Nom de discipline (depuis ta table discipline)
    private String mapDisciplineIdToName(int id) {
        switch (id) {
            case 1: return "Boxing";
            case 2: return "MMA";
            case 3: return "Judo";
            case 4: return "Kickboxing";
            case 5: return "Wrestling";
            default: return "Unknown";
        }
    }

    // ✅ Nom → ID de discipline (pour le filtre)
    private int mapDisciplineNameToId(String name) {
        switch (name) {
            case "Boxing":     return 1;
            case "MMA":        return 2;
            case "Judo":       return 3;
            case "Kickboxing": return 4;
            case "Wrestling":  return 5;
            default: return 0;
        }
    }

    private void recalculateRankings() {
        String selected = cmbWeightClass.getValue();
        int id = (selected == null || selected.equals("All")) ? 1 : mapDisciplineNameToId(selected);
        controller.recalculateRankings(id > 0 ? id : 1);
        refresh();
    }

    public void refresh() {
        controller.loadAllRankings();
        updateChart();
    }

    private void updateRankingCount() {
        Platform.runLater(() -> {
            int count = controller.getRankings().size();
            lblRankingCount.setText(count + " classement" + (count > 1 ? "s" : ""));
        });
    }

    public BorderPane getView() {
        return view;
    }
}