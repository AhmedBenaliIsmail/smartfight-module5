package com.smartfight.view;

import com.smartfight.controller.MainController;
import com.smartfight.view.scenes.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

/**
 * Vue principale de l'application avec navigation
 * VERSION CORRIGÉE - Gestion améliorée de la navigation et des états
 */
public class MainView {
    private BorderPane root;
    private MainController controller;
    
    // Scènes
    private DashboardScene dashboardScene;
    private FightersScene fightersScene;
    private MatchmakingScene matchmakingScene;
    private RankingsScene rankingsScene;
    
    // Boutons de navigation
    private Button btnDashboard;
    private Button btnFighters;
    private Button btnMatchmaking;
    private Button btnRankings;
    
    // Constantes de style
    private static final String COLOR_PRIMARY = "#3498db";
    private static final String COLOR_SIDEBAR = "#2c3e50";
    private static final String COLOR_SIDEBAR_HOVER = "#34495e";
    private static final String COLOR_TEXT_LIGHT = "#ecf0f1";
    private static final String COLOR_TEXT_MUTED = "#95a5a6";
    
    public MainView() {
        try {
            this.controller = new MainController();
            initializeUI();
            System.out.println("✓ MainView initialisée avec succès");
        } catch (Exception e) {
            System.err.println("❌ Erreur lors de l'initialisation de la vue: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Impossible d'initialiser la vue principale", e);
        }
    }
    
    private void initializeUI() {
        root = new BorderPane();
        root.setStyle("-fx-background-color: #f5f5f5;");
        
        // Header
        root.setTop(createHeader());
        
        // Sidebar
        root.setLeft(createSidebar());
        
        // Initialiser les scènes avec gestion d'erreurs
        try {
            dashboardScene = new DashboardScene(controller);
            System.out.println("✓ DashboardScene créée");
        } catch (Exception e) {
            System.err.println("❌ Erreur lors de la création de DashboardScene: " + e.getMessage());
        }
        
        try {
            fightersScene = new FightersScene(controller);
            System.out.println("✓ FightersScene créée");
        } catch (Exception e) {
            System.err.println("❌ Erreur lors de la création de FightersScene: " + e.getMessage());
        }
        
        try {
            matchmakingScene = new MatchmakingScene(controller);
            System.out.println("✓ MatchmakingScene créée");
        } catch (Exception e) {
            System.err.println("❌ Erreur lors de la création de MatchmakingScene: " + e.getMessage());
        }
        
        try {
            rankingsScene = new RankingsScene(controller);
            System.out.println("✓ RankingsScene créée");
        } catch (Exception e) {
            System.err.println("❌ Erreur lors de la création de RankingsScene: " + e.getMessage());
        }
        
        // Afficher le dashboard par défaut
        showDashboard();
    }
    
    /**
     * Crée le header de l'application
     */
    private HBox createHeader() {
        HBox header = new HBox();
        header.setPadding(new Insets(20, 30, 20, 30));
        header.setAlignment(Pos.CENTER_LEFT);
        header.setStyle("-fx-background-color: linear-gradient(to right, #1e3c72, #2a5298); " +
                       "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0, 0, 2);");
        
        // Logo et titre
        Label title = new Label("🥊 SmartFight");
        title.setStyle("-fx-font-size: 32px; -fx-font-weight: bold; -fx-text-fill: white;");
        
        Label subtitle = new Label("AI Matchmaking & Rankings System");
        subtitle.setStyle("-fx-font-size: 14px; -fx-text-fill: #e0e0e0; -fx-padding: 8 0 0 10;");
        
        VBox titleBox = new VBox(5, title, subtitle);
        
        header.getChildren().add(titleBox);
        
        return header;
    }
    
    /**
     * Crée la sidebar de navigation
     */
    private VBox createSidebar() {
        VBox sidebar = new VBox(10);
        sidebar.setPadding(new Insets(20));
        sidebar.setPrefWidth(220);
        sidebar.setStyle("-fx-background-color: " + COLOR_SIDEBAR + ";");
        
        // Titre de la navigation
        Label navTitle = new Label("NAVIGATION");
        navTitle.setStyle("-fx-text-fill: " + COLOR_TEXT_MUTED + "; -fx-font-size: 12px; " +
                         "-fx-font-weight: bold; -fx-padding: 10 0 10 0;");
        
        // Boutons de navigation
        btnDashboard = createNavButton("📊 Dashboard", true);
        btnFighters = createNavButton("🥋 Combattants", false);
        btnMatchmaking = createNavButton("⚔️ Matchmaking", false);
        btnRankings = createNavButton("🏆 Classements", false);
        
        // Actions des boutons avec gestion d'erreurs
        btnDashboard.setOnAction(e -> safeNavigate(this::showDashboard, "Dashboard"));
        btnFighters.setOnAction(e -> safeNavigate(this::showFighters, "Combattants"));
        btnMatchmaking.setOnAction(e -> safeNavigate(this::showMatchmaking, "Matchmaking"));
        btnRankings.setOnAction(e -> safeNavigate(this::showRankings, "Classements"));
        
        // Spacer pour pousser les éléments vers le bas
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        
        // Info version
        Label versionLabel = new Label("v1.0.0");
        versionLabel.setStyle("-fx-text-fill: " + COLOR_TEXT_MUTED + "; -fx-font-size: 11px; " +
                            "-fx-padding: 10 0 0 0;");
        
        sidebar.getChildren().addAll(
            navTitle,
            btnDashboard,
            btnFighters,
            btnMatchmaking,
            btnRankings,
            spacer,
            versionLabel
        );
        
        return sidebar;
    }
    
    /**
     * Crée un bouton de navigation avec style
     */
    private Button createNavButton(String text, boolean active) {
        Button button = new Button(text);
        button.setMaxWidth(Double.MAX_VALUE);
        button.setAlignment(Pos.CENTER_LEFT);
        button.setPadding(new Insets(15, 20, 15, 20));
        
        if (active) {
            button.setStyle("-fx-background-color: " + COLOR_PRIMARY + "; -fx-text-fill: white; " +
                           "-fx-font-size: 14px; -fx-font-weight: bold; " +
                           "-fx-background-radius: 5; -fx-cursor: hand;");
        } else {
            button.setStyle("-fx-background-color: transparent; -fx-text-fill: " + COLOR_TEXT_LIGHT + "; " +
                           "-fx-font-size: 14px; -fx-background-radius: 5; -fx-cursor: hand;");
        }
        
        // Effet hover
        button.setOnMouseEntered(e -> {
            if (!button.getStyle().contains(COLOR_PRIMARY)) {
                button.setStyle("-fx-background-color: " + COLOR_SIDEBAR_HOVER + "; -fx-text-fill: white; " +
                               "-fx-font-size: 14px; -fx-background-radius: 5; -fx-cursor: hand;");
            }
        });
        
        button.setOnMouseExited(e -> {
            if (!button.getStyle().contains(COLOR_PRIMARY)) {
                button.setStyle("-fx-background-color: transparent; -fx-text-fill: " + COLOR_TEXT_LIGHT + "; " +
                               "-fx-font-size: 14px; -fx-background-radius: 5; -fx-cursor: hand;");
            }
        });
        
        return button;
    }
    
    /**
     * Met à jour l'état actif des boutons de navigation
     */
    private void updateActiveButton(Button activeButton) {
        // Réinitialiser tous les boutons
        for (Button btn : new Button[]{btnDashboard, btnFighters, btnMatchmaking, btnRankings}) {
            if (btn != null) {
                btn.setStyle("-fx-background-color: transparent; -fx-text-fill: " + COLOR_TEXT_LIGHT + "; " +
                            "-fx-font-size: 14px; -fx-background-radius: 5; -fx-cursor: hand;");
            }
        }
        
        // Activer le bouton sélectionné
        if (activeButton != null) {
            activeButton.setStyle("-fx-background-color: " + COLOR_PRIMARY + "; -fx-text-fill: white; " +
                                 "-fx-font-size: 14px; -fx-font-weight: bold; " +
                                 "-fx-background-radius: 5; -fx-cursor: hand;");
        }
    }
    
    /**
     * Navigation sécurisée avec gestion d'erreurs
     */
    private void safeNavigate(Runnable navigationAction, String sceneName) {
        try {
            navigationAction.run();
        } catch (Exception e) {
            System.err.println("❌ Erreur lors de la navigation vers " + sceneName + ": " + e.getMessage());
            e.printStackTrace();
            
            // Afficher un message d'erreur dans le centre
            VBox errorBox = new VBox(20);
            errorBox.setAlignment(Pos.CENTER);
            errorBox.setPadding(new Insets(50));
            
            Label errorIcon = new Label("⚠️");
            errorIcon.setStyle("-fx-font-size: 64px;");
            
            Label errorTitle = new Label("Erreur de chargement");
            errorTitle.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #e74c3c;");
            
            Label errorMessage = new Label("Impossible de charger la scène " + sceneName);
            errorMessage.setStyle("-fx-font-size: 14px; -fx-text-fill: #7f8c8d;");
            
            errorBox.getChildren().addAll(errorIcon, errorTitle, errorMessage);
            root.setCenter(errorBox);
        }
    }
    
    // Méthodes de navigation
    private void showDashboard() {
        if (dashboardScene != null) {
            updateActiveButton(btnDashboard);
            root.setCenter(dashboardScene.getView());
            dashboardScene.refresh();
            System.out.println("→ Navigation: Dashboard");
        } else {
            System.err.println("⚠️ DashboardScene non disponible");
        }
    }
    
    private void showFighters() {
        if (fightersScene != null) {
            updateActiveButton(btnFighters);
            root.setCenter(fightersScene.getView());
            fightersScene.refresh();
            System.out.println("→ Navigation: Combattants");
        } else {
            System.err.println("⚠️ FightersScene non disponible");
        }
    }
    
    private void showMatchmaking() {
        if (matchmakingScene != null) {
            updateActiveButton(btnMatchmaking);
            root.setCenter(matchmakingScene.getView());
            matchmakingScene.refresh();
            System.out.println("→ Navigation: Matchmaking");
        } else {
            System.err.println("⚠️ MatchmakingScene non disponible");
        }
    }
    
    private void showRankings() {
        if (rankingsScene != null) {
            updateActiveButton(btnRankings);
            root.setCenter(rankingsScene.getView());
            rankingsScene.refresh();
            System.out.println("→ Navigation: Classements");
        } else {
            System.err.println("⚠️ RankingsScene non disponible");
        }
    }
    
    /**
     * Retourne le nœud racine de la vue
     */
    public BorderPane getRoot() {
        return root;
    }
    
    /**
     * Retourne le contrôleur principal
     */
    public MainController getController() {
        return controller;
    }
    
    /**
     * Libère les ressources de la vue
     */
    public void dispose() {
        try {
            if (controller != null) {
                controller.dispose();
            }
            System.out.println("✓ Ressources de MainView libérées");
        } catch (Exception e) {
            System.err.println("⚠️ Erreur lors du nettoyage de MainView: " + e.getMessage());
        }
    }
}
