package com.smartfight.dao;

import com.smartfight.model.WeightClass;
import com.smartfight.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO pour la gestion des catégories de poids
 */
public class WeightClassDAO {
    private Connection connection;
    
    public WeightClassDAO() {
        this.connection = DatabaseConnection.getConnection();
    }
    
    /**
     * Récupère toutes les catégories de poids
     */
    public List<WeightClass> getAllWeightClasses() {
        List<WeightClass> weightClasses = new ArrayList<>();
        String query = "SELECT wc.*, d.name as discipline_name " +
                      "FROM weight_class wc " +
                      "LEFT JOIN discipline d ON wc.discipline_id = d.id " +
                      "ORDER BY wc.min_weight_kg";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                weightClasses.add(extractWeightClassFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération des catégories de poids");
            e.printStackTrace();
        }
        
        return weightClasses;
    }
    
    /**
     * Récupère une catégorie de poids par son ID
     */
    public WeightClass getWeightClassById(int id) {
        String query = "SELECT wc.*, d.name as discipline_name " +
                      "FROM weight_class wc " +
                      "LEFT JOIN discipline d ON wc.discipline_id = d.id " +
                      "WHERE wc.id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractWeightClassFromResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération de la catégorie de poids");
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Récupère les catégories de poids par discipline
     */
    public List<WeightClass> getWeightClassesByDiscipline(int disciplineId) {
        List<WeightClass> weightClasses = new ArrayList<>();
        String query = "SELECT wc.*, d.name as discipline_name " +
                      "FROM weight_class wc " +
                      "LEFT JOIN discipline d ON wc.discipline_id = d.id " +
                      "WHERE wc.discipline_id = ? " +
                      "ORDER BY wc.min_weight_kg";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, disciplineId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                weightClasses.add(extractWeightClassFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return weightClasses;
    }
    
    /**
     * Trouve la catégorie de poids appropriée pour un poids donné
     */
    public WeightClass findWeightClassForWeight(double weightKg, int disciplineId) {
        String query = "SELECT wc.*, d.name as discipline_name " +
                      "FROM weight_class wc " +
                      "LEFT JOIN discipline d ON wc.discipline_id = d.id " +
                      "WHERE wc.discipline_id = ? " +
                      "AND ? >= wc.min_weight_kg AND ? <= wc.max_weight_kg";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, disciplineId);
            pstmt.setDouble(2, weightKg);
            pstmt.setDouble(3, weightKg);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractWeightClassFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Extrait un WeightClass depuis un ResultSet
     */
    private WeightClass extractWeightClassFromResultSet(ResultSet rs) throws SQLException {
        WeightClass weightClass = new WeightClass();
        weightClass.setId(rs.getInt("id"));
        weightClass.setName(rs.getString("name"));
        weightClass.setMinWeightKg(rs.getDouble("min_weight_kg"));
        weightClass.setMaxWeightKg(rs.getDouble("max_weight_kg"));
        weightClass.setDisciplineId(rs.getInt("discipline_id"));
        
        try {
            weightClass.setDisciplineName(rs.getString("discipline_name"));
        } catch (SQLException e) {
            // Colonne non disponible
        }
        
        return weightClass;
    }
}
