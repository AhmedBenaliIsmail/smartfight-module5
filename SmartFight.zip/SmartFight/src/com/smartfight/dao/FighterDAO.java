package com.smartfight.dao;

import com.smartfight.model.Fighter;
import com.smartfight.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO pour la gestion des combattants
 * CORRECTION : connexion fraîche à chaque méthode pour éviter les timeouts
 */
public class FighterDAO {

    // ← Plus de champ 'connection' stocké — on appelle getConnection() à chaque fois

    public FighterDAO() {
        // Constructeur vide — la connexion est récupérée dynamiquement
    }

    public List<Fighter> getAllFighters() {
        List<Fighter> fighters = new ArrayList<>();
        String query = "SELECT * FROM fighter ORDER BY id";

        try (Statement stmt = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                fighters.add(extractFighterFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération des combattants");
            e.printStackTrace();
        }
        return fighters;
    }

    public Fighter getFighterById(int id) {
        String query = "SELECT * FROM fighter WHERE id = ?";

        try (PreparedStatement pstmt = DatabaseConnection.getConnection().prepareStatement(query)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return extractFighterFromResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération du combattant #" + id);
            e.printStackTrace();
        }
        return null;
    }

    public List<Fighter> getFightersByWeightClass(int weightClassId) {
        List<Fighter> fighters = new ArrayList<>();
        String query = "SELECT * FROM fighter WHERE weight_class_id = ? ORDER BY wins DESC";

        try (PreparedStatement pstmt = DatabaseConnection.getConnection().prepareStatement(query)) {
            pstmt.setInt(1, weightClassId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                fighters.add(extractFighterFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération des combattants par catégorie");
            e.printStackTrace();
        }
        return fighters;
    }

    public List<Fighter> getFightersByDiscipline(int disciplineId) {
        List<Fighter> fighters = new ArrayList<>();
        String query = "SELECT * FROM fighter WHERE discipline_id = ?";

        try (PreparedStatement pstmt = DatabaseConnection.getConnection().prepareStatement(query)) {
            pstmt.setInt(1, disciplineId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                fighters.add(extractFighterFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fighters;
    }

    public boolean addFighter(Fighter fighter) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            
            // 1. Créer un user avec les bonnes colonnes
            String insertUser = "INSERT INTO user (first_name, last_name, email, password, role_id) " +
                               "VALUES (?, ?, ?, '123456', 1)";
            int newUserId = -1;
            
            try (PreparedStatement pstmt = conn.prepareStatement(
                    insertUser, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setString(1, fighter.getName());   // first_name
                pstmt.setString(2, "Fighter");            // last_name
                // email unique basé sur timestamp
                pstmt.setString(3, fighter.getName().replaceAll("\\s+", "") 
                               + System.currentTimeMillis() + "@smartfight.com");
                pstmt.executeUpdate();
                ResultSet keys = pstmt.getGeneratedKeys();
                if (keys.next()) newUserId = keys.getInt(1);
            }
            
            if (newUserId == -1) return false;
            
            // 2. Insérer le fighter
            String insertFighter = "INSERT INTO fighter (user_id, nickname, date_of_birth, nationality, " +
                                  "weight_class_id, wins, losses, draws, status) " +
                                  "VALUES (?, ?, ?, ?, 1, ?, ?, ?, 'ACTIVE')";
            
            try (PreparedStatement pstmt = conn.prepareStatement(
                    insertFighter, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setInt(1, newUserId);
                pstmt.setString(2, fighter.getName());
                pstmt.setDate(3, fighter.getDateOfBirth() != null ?
                        Date.valueOf(fighter.getDateOfBirth()) : Date.valueOf("2000-01-01"));
                pstmt.setString(4, fighter.getNationality() != null ? 
                        fighter.getNationality() : "Unknown");
                pstmt.setInt(5, fighter.getWins());
                pstmt.setInt(6, fighter.getLosses());
                pstmt.setInt(7, fighter.getDraws());
                
                int rows = pstmt.executeUpdate();
                if (rows > 0) {
                    ResultSet keys = pstmt.getGeneratedKeys();
                    if (keys.next()) fighter.setId(keys.getInt(1));
                    return true;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'ajout du combattant");
            e.printStackTrace();
        }
        return false;
    }
    

    public boolean updateFighter(Fighter fighter) {
        String query = "UPDATE fighter SET nickname=?, date_of_birth=?, nationality=?, " +
                      "weight_class_id=?, wins=?, losses=?, draws=? WHERE id=?";

        try (PreparedStatement pstmt = DatabaseConnection.getConnection().prepareStatement(query)) {
            pstmt.setString(1, fighter.getName());
            pstmt.setDate(2, fighter.getDateOfBirth() != null ?
                    Date.valueOf(fighter.getDateOfBirth()) : Date.valueOf("2000-01-01"));
            pstmt.setString(3, fighter.getNationality());
            pstmt.setInt(4, fighter.getWeightClassId() > 0 ? fighter.getWeightClassId() : 1);
            pstmt.setInt(5, fighter.getWins());
            pstmt.setInt(6, fighter.getLosses());
            pstmt.setInt(7, fighter.getDraws());
            pstmt.setInt(8, fighter.getId());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Erreur lors de la mise à jour du combattant");
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteFighter(int id) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            
            // Désactiver les contraintes FK
            conn.prepareStatement("SET FOREIGN_KEY_CHECKS = 0").executeUpdate();
            
            // Supprimer le combattant
            try (PreparedStatement pstmt = conn.prepareStatement(
                    "DELETE FROM fighter WHERE id = ?")) {
                pstmt.setInt(1, id);
                boolean result = pstmt.executeUpdate() > 0;
                
                // Réactiver les contraintes FK
                conn.prepareStatement("SET FOREIGN_KEY_CHECKS = 1").executeUpdate();
                return result;
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression du combattant");
            e.printStackTrace();
            try {
                DatabaseConnection.getConnection()
                    .prepareStatement("SET FOREIGN_KEY_CHECKS = 1").executeUpdate();
            } catch (SQLException ex) { }
        }
        return false;
    }

    public List<Fighter> searchFighters(String searchTerm) {
        List<Fighter> fighters = new ArrayList<>();
        String query = "SELECT * FROM fighter WHERE nickname LIKE ?";

        try (PreparedStatement pstmt = DatabaseConnection.getConnection().prepareStatement(query)) {
            pstmt.setString(1, "%" + searchTerm + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                fighters.add(extractFighterFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fighters;
    }

    private Fighter extractFighterFromResultSet(ResultSet rs) throws SQLException {
        Fighter fighter = new Fighter();
        fighter.setId(rs.getInt("id"));
        fighter.setName(rs.getString("nickname"));
        fighter.setSurname("");

        Date dob = rs.getDate("date_of_birth");
        if (dob != null) fighter.setDateOfBirth(dob.toLocalDate());

        fighter.setNationality(rs.getString("nationality"));
        fighter.setHeightCm(0);
        fighter.setWeightKg(0);
        fighter.setWins(rs.getInt("wins"));
        fighter.setLosses(rs.getInt("losses"));
        fighter.setDraws(rs.getInt("draws"));
        fighter.setStance("");
        fighter.setDisciplineId(0);
        fighter.setWeightClassId(rs.getInt("weight_class_id"));

        return fighter;
    }
}