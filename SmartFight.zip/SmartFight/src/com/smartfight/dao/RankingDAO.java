package com.smartfight.dao;

import com.smartfight.model.Ranking;
import com.smartfight.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO pour la gestion des classements
 */
public class RankingDAO {
    private Connection connection;
    
    public RankingDAO() {
        this.connection = DatabaseConnection.getConnection();
    }
    
    /**
     * Récupère tous les classements
     */
    public List<Ranking> getAllRankings() {
        List<Ranking> rankings = new ArrayList<>();
        String query = "SELECT r.*, f.nickname, d.name as weight_class_name " +
                      "FROM ranking r " +
                      "JOIN fighter f ON r.fighter_id = f.id " +
                      "JOIN discipline d ON r.discipline_id = d.id " +
                      "ORDER BY r.discipline_id, r.rank_position";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                rankings.add(extractRankingFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération des classements");
            e.printStackTrace();
        }
        return rankings;
    }

    public List<Ranking> getRankingsByWeightClass(int disciplineId) {
        List<Ranking> rankings = new ArrayList<>();
        String query = "SELECT r.*, f.nickname, f.wins, f.losses, f.draws, " +
                      "d.name as weight_class_name " +
                      "FROM ranking r " +
                      "JOIN fighter f ON r.fighter_id = f.id " +
                      "JOIN discipline d ON r.discipline_id = d.id " +
                      "WHERE r.discipline_id = ? " +
                      "ORDER BY r.rank_position";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, disciplineId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                rankings.add(extractRankingFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rankings;
    }

    public Ranking getRankingByFighter(int fighterId) {
        String query = "SELECT r.*, f.nickname, d.name as weight_class_name " +
                      "FROM ranking r " +
                      "JOIN fighter f ON r.fighter_id = f.id " +
                      "JOIN discipline d ON r.discipline_id = d.id " +
                      "WHERE r.fighter_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, fighterId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return extractRankingFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * Ajoute ou met à jour un classement
     */
    public boolean saveRanking(Ranking ranking) {
        // ← weight_class_id → discipline_id
        String checkQuery = "SELECT id FROM ranking WHERE fighter_id = ? AND discipline_id = ?";
        
        try (PreparedStatement checkStmt = connection.prepareStatement(checkQuery)) {
            checkStmt.setInt(1, ranking.getFighterId());
            checkStmt.setInt(2, ranking.getWeightClassId());
            ResultSet rs = checkStmt.executeQuery();
            
            if (rs.next()) {
                return updateRanking(ranking);
            } else {
                return insertRanking(ranking);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * Insère un nouveau classement
     */
    private boolean insertRanking(Ranking ranking) {
        String query = "INSERT INTO ranking (fighter_id, discipline_id, rank_position, points, season) " +
                      "VALUES (?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, ranking.getFighterId());
            pstmt.setInt(2, ranking.getWeightClassId());   // discipline_id
            pstmt.setInt(3, ranking.getRank());             // rank_position
            pstmt.setDouble(4, ranking.getScore());         // points
            pstmt.setInt(5, 2026);                          // season
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                ResultSet generatedKeys = pstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    ranking.setId(generatedKeys.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean updateRanking(Ranking ranking) {
        String query = "UPDATE ranking SET rank_position=?, points=? " +
                      "WHERE fighter_id=? AND discipline_id=?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, ranking.getRank());
            pstmt.setDouble(2, ranking.getScore());
            pstmt.setInt(3, ranking.getFighterId());
            pstmt.setInt(4, ranking.getWeightClassId());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * Supprime un classement
     */
    public boolean deleteRanking(int id) {
        String query = "DELETE FROM ranking WHERE id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression du classement");
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Supprime tous les classements d'une catégorie de poids
     */
    public boolean deleteRankingsByWeightClass(int disciplineId) {
        // ← weight_class_id → discipline_id
        String query = "DELETE FROM ranking WHERE discipline_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, disciplineId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * Extrait un Ranking depuis un ResultSet
     */
    private Ranking extractRankingFromResultSet(ResultSet rs) throws SQLException {
        Ranking ranking = new Ranking();
        ranking.setId(rs.getInt("id"));
        ranking.setFighterId(rs.getInt("fighter_id"));
        ranking.setWeightClassId(rs.getInt("discipline_id"));  // discipline_id → weightClassId
        ranking.setRank(rs.getInt("rank_position"));            // rank_position → rank
        ranking.setScore(rs.getDouble("points"));               // points → score
        
        Date updatedAt = rs.getDate("updated_at");
        if (updatedAt != null) {
            ranking.setLastUpdated(updatedAt.toLocalDate());
        }
        
        try {
            ranking.setWeightClassName(rs.getString("weight_class_name"));
        } catch (SQLException e) { }
        
        try {
            ranking.setFighterName(rs.getString("nickname"));
        } catch (SQLException e) { }
        
        return ranking;
    }
}
