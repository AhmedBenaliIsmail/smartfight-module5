package com.smartfight.model;

/**
 * Modèle représentant les statistiques d'un combat
 */
public class FightStatistic {
    private int id;
    private int fightResultId;
    private int fighterId;
    private int strikesLanded;
    private int strikesAttempted;
    private int takedownsLanded;
    private int takedownsAttempted;
    private int submissionAttempts;
    private int knockdowns;
    private int controlTimeSeconds;
    private int significantStrikes;
    
    // Constructeur par défaut
    public FightStatistic() {
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getFightResultId() { return fightResultId; }
    public void setFightResultId(int fightResultId) { this.fightResultId = fightResultId; }
    
    public int getFighterId() { return fighterId; }
    public void setFighterId(int fighterId) { this.fighterId = fighterId; }
    
    public int getStrikesLanded() { return strikesLanded; }
    public void setStrikesLanded(int strikesLanded) { this.strikesLanded = strikesLanded; }
    
    public int getStrikesAttempted() { return strikesAttempted; }
    public void setStrikesAttempted(int strikesAttempted) { this.strikesAttempted = strikesAttempted; }
    
    public int getTakedownsLanded() { return takedownsLanded; }
    public void setTakedownsLanded(int takedownsLanded) { this.takedownsLanded = takedownsLanded; }
    
    public int getTakedownsAttempted() { return takedownsAttempted; }
    public void setTakedownsAttempted(int takedownsAttempted) { this.takedownsAttempted = takedownsAttempted; }
    
    public int getSubmissionAttempts() { return submissionAttempts; }
    public void setSubmissionAttempts(int submissionAttempts) { this.submissionAttempts = submissionAttempts; }
    
    public int getKnockdowns() { return knockdowns; }
    public void setKnockdowns(int knockdowns) { this.knockdowns = knockdowns; }
    
    public int getControlTimeSeconds() { return controlTimeSeconds; }
    public void setControlTimeSeconds(int controlTimeSeconds) { this.controlTimeSeconds = controlTimeSeconds; }
    
    public int getSignificantStrikes() { return significantStrikes; }
    public void setSignificantStrikes(int significantStrikes) { this.significantStrikes = significantStrikes; }
    
    // Calcul de la précision des frappes
    public double getStrikeAccuracy() {
        return strikesAttempted > 0 ? (double) strikesLanded / strikesAttempted * 100 : 0;
    }
    
    // Calcul de la précision des takedowns
    public double getTakedownAccuracy() {
        return takedownsAttempted > 0 ? (double) takedownsLanded / takedownsAttempted * 100 : 0;
    }
}
