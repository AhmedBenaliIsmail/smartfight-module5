package com.smartfight.model;

import java.time.LocalDate;

/**
 * Modèle représentant le classement d'un combattant
 */
public class Ranking {
    private int id;
    private int fighterId;
    private int weightClassId;
    private int rank;
    private double score;
    private int previousRank;
    private LocalDate lastUpdated;
    private String trend; // UP, DOWN, STABLE
    private String fighterName;
    
    // Informations du combattant (pour affichage)
    private Fighter fighter;
    private String weightClassName;
    
    // Constructeur par défaut
    public Ranking() {
        this.lastUpdated = LocalDate.now();
        this.trend = "STABLE";
    }
    
    // Constructeur avec données
    public Ranking(int fighterId, int weightClassId, int rank, double score) {
        this();
        this.fighterId = fighterId;
        this.weightClassId = weightClassId;
        this.rank = rank;
        this.score = score;
        this.previousRank = rank;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getFighterId() { return fighterId; }
    public void setFighterId(int fighterId) { this.fighterId = fighterId; }
    
    public int getWeightClassId() { return weightClassId; }
    public void setWeightClassId(int weightClassId) { this.weightClassId = weightClassId; }
    
    public int getRank() { return rank; }
    public void setRank(int rank) { 
        this.previousRank = this.rank;
        this.rank = rank;
        updateTrend();
    }
    
    public double getScore() { return score; }
    public void setScore(double score) { this.score = score; }
    
    public int getPreviousRank() { return previousRank; }
    public void setPreviousRank(int previousRank) { 
        this.previousRank = previousRank;
        updateTrend();
    }
    
    public LocalDate getLastUpdated() { return lastUpdated; }
    public void setLastUpdated(LocalDate lastUpdated) { this.lastUpdated = lastUpdated; }
    
    public String getTrend() { return trend; }
    public void setTrend(String trend) { this.trend = trend; }
    
    public Fighter getFighter() { return fighter; }
    public void setFighter(Fighter fighter) { this.fighter = fighter; }
    
    public String getWeightClassName() { return weightClassName; }
    public void setWeightClassName(String weightClassName) { this.weightClassName = weightClassName; }
    
    // Calcul de la tendance
    private void updateTrend() {
        if (previousRank == 0 || rank == previousRank) {
            trend = "STABLE";
        } else if (rank < previousRank) {
            trend = "UP"; // Rang inférieur = meilleure position
        } else {
            trend = "DOWN";
        }
    }
    
    // Différence de rang
    public int getRankDifference() {
        if (previousRank == 0) return 0;
        return previousRank - rank; // Positif = montée
    }
    
    // Emoji de tendance
    public String getTrendEmoji() {
        switch (trend) {
            case "UP": return "↑";
            case "DOWN": return "↓";
            default: return "→";
        }
    }
    
    @Override
    public String toString() {
        String fighterName = fighter != null ? fighter.getFullName() : "Fighter #" + fighterId;
        return "#" + rank + " " + fighterName + " (" + String.format("%.1f", score) + ")";
    }

	public String getFighterName() {
		return fighterName;
	}

	public void setFighterName(String fighterName) {
		this.fighterName = fighterName;
	}
}
