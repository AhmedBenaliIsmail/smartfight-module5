package com.smartfight.model;

import java.time.LocalDateTime;

/**
 * Modèle représentant une proposition de match générée par l'algorithme de matchmaking
 */
public class MatchProposal {
    private int id;
    private int fighter1Id;
    private int fighter2Id;
    private Fighter fighter1;
    private Fighter fighter2;
    private int eventId;
    private double matchScore; // Score de qualité du match (0-100)
    private String status; // PROPOSED, ACCEPTED, REJECTED, SCHEDULED
    private LocalDateTime proposedDate;
    private String matchType; // TITLE_FIGHT, MAIN_EVENT, CO_MAIN, UNDERCARD
    private int weightClassId;
    private String reasoning; // Explication de pourquoi ce match est proposé
    
    // Constructeur par défaut
    public MatchProposal() {
        this.proposedDate = LocalDateTime.now();
        this.status = "PROPOSED";
    }
    
    // Constructeur avec fighters
    public MatchProposal(Fighter fighter1, Fighter fighter2, double matchScore) {
        this();
        this.fighter1 = fighter1;
        this.fighter2 = fighter2;
        this.fighter1Id = fighter1.getId();
        this.fighter2Id = fighter2.getId();
        this.matchScore = matchScore;
        this.weightClassId = fighter1.getWeightClassId();
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getFighter1Id() { return fighter1Id; }
    public void setFighter1Id(int fighter1Id) { this.fighter1Id = fighter1Id; }
    
    public int getFighter2Id() { return fighter2Id; }
    public void setFighter2Id(int fighter2Id) { this.fighter2Id = fighter2Id; }
    
    public Fighter getFighter1() { return fighter1; }
    public void setFighter1(Fighter fighter1) { 
        this.fighter1 = fighter1;
        if (fighter1 != null) this.fighter1Id = fighter1.getId();
    }
    
    public Fighter getFighter2() { return fighter2; }
    public void setFighter2(Fighter fighter2) { 
        this.fighter2 = fighter2;
        if (fighter2 != null) this.fighter2Id = fighter2.getId();
    }
    
    public int getEventId() { return eventId; }
    public void setEventId(int eventId) { this.eventId = eventId; }
    
    public double getMatchScore() { return matchScore; }
    public void setMatchScore(double matchScore) { this.matchScore = matchScore; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public LocalDateTime getProposedDate() { return proposedDate; }
    public void setProposedDate(LocalDateTime proposedDate) { this.proposedDate = proposedDate; }
    
    public String getMatchType() { return matchType; }
    public void setMatchType(String matchType) { this.matchType = matchType; }
    
    public int getWeightClassId() { return weightClassId; }
    public void setWeightClassId(int weightClassId) { this.weightClassId = weightClassId; }
    
    public String getReasoning() { return reasoning; }
    public void setReasoning(String reasoning) { this.reasoning = reasoning; }
    
    // Méthode utilitaire pour obtenir le nom du match
    public String getMatchName() {
        if (fighter1 != null && fighter2 != null) {
            return fighter1.getFullName() + " vs " + fighter2.getFullName();
        }
        return "Match #" + id;
    }
    
    // Vérifie si le match est équilibré
    public boolean isBalanced() {
        if (fighter1 == null || fighter2 == null) return false;
        
        double winRateDiff = Math.abs(fighter1.getWinRate() - fighter2.getWinRate());
        int experienceDiff = Math.abs(fighter1.getExperience() - fighter2.getExperience());
        
        return winRateDiff < 20 && experienceDiff < 5;
    }
    
    @Override
    public String toString() {
        return getMatchName() + " (Score: " + String.format("%.1f", matchScore) + ")";
    }
}
