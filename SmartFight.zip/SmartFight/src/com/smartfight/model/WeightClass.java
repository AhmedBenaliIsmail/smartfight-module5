package com.smartfight.model;

/**
 * Modèle représentant une catégorie de poids
 */
public class WeightClass {
    private int id;
    private String name;
    private double minWeightKg;
    private double maxWeightKg;
    private int disciplineId;
    private String disciplineName;
    
    // Constructeur par défaut
    public WeightClass() {
    }
    
    public WeightClass(int id, String name, double minWeightKg, double maxWeightKg) {
        this.id = id;
        this.name = name;
        this.minWeightKg = minWeightKg;
        this.maxWeightKg = maxWeightKg;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public double getMinWeightKg() { return minWeightKg; }
    public void setMinWeightKg(double minWeightKg) { this.minWeightKg = minWeightKg; }
    
    public double getMaxWeightKg() { return maxWeightKg; }
    public void setMaxWeightKg(double maxWeightKg) { this.maxWeightKg = maxWeightKg; }
    
    public int getDisciplineId() { return disciplineId; }
    public void setDisciplineId(int disciplineId) { this.disciplineId = disciplineId; }
    
    public String getDisciplineName() { return disciplineName; }
    public void setDisciplineName(String disciplineName) { this.disciplineName = disciplineName; }
    
    // Vérifie si un poids est dans cette catégorie
    public boolean isInRange(double weight) {
        return weight >= minWeightKg && weight <= maxWeightKg;
    }
    
    @Override
    public String toString() {
        return name + " (" + minWeightKg + "-" + maxWeightKg + " kg)";
    }
}
