package com.smartfight.model;

import java.time.LocalDate;

/**
 * Modèle représentant un combattant
 */
public class Fighter {
    private int id;
    private String name;
    private String surname;
    private LocalDate dateOfBirth;
    private String nationality;
    private int heightCm;
    private double weightKg;
    private int wins;
    private int losses;
    private int draws;
    private String stance; // Orthodox, Southpaw, Switch
    private int disciplineId;
    private int weightClassId;
    private double rankingScore;
    private int experience; // nombre de combats
    private String profileImage;
    
    // Constructeur par défaut
    public Fighter() {
    }
    
    // Constructeur complet
    public Fighter(int id, String name, String surname, LocalDate dateOfBirth, 
                   String nationality, int heightCm, double weightKg, int wins, 
                   int losses, int draws, String stance, int disciplineId, 
                   int weightClassId) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.dateOfBirth = dateOfBirth;
        this.nationality = nationality;
        this.heightCm = heightCm;
        this.weightKg = weightKg;
        this.wins = wins;
        this.losses = losses;
        this.draws = draws;
        this.stance = stance;
        this.disciplineId = disciplineId;
        this.weightClassId = weightClassId;
        this.experience = wins + losses + draws;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getSurname() { return surname; }
    public void setSurname(String surname) { this.surname = surname; }
    
    public String getFullName() { return name + " " + surname; }
    
    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }
    
    public String getNationality() { return nationality; }
    public void setNationality(String nationality) { this.nationality = nationality; }
    
    public int getHeightCm() { return heightCm; }
    public void setHeightCm(int heightCm) { this.heightCm = heightCm; }
    
    public double getWeightKg() { return weightKg; }
    public void setWeightKg(double weightKg) { this.weightKg = weightKg; }
    
    public int getWins() { return wins; }
    public void setWins(int wins) { 
        this.wins = wins;
        this.experience = wins + losses + draws;
    }
    
    public int getLosses() { return losses; }
    public void setLosses(int losses) { 
        this.losses = losses;
        this.experience = wins + losses + draws;
    }
    
    public int getDraws() { return draws; }
    public void setDraws(int draws) { 
        this.draws = draws;
        this.experience = wins + losses + draws;
    }
    
    public String getStance() { return stance; }
    public void setStance(String stance) { this.stance = stance; }
    
    public int getDisciplineId() { return disciplineId; }
    public void setDisciplineId(int disciplineId) { this.disciplineId = disciplineId; }
    
    public int getWeightClassId() { return weightClassId; }
    public void setWeightClassId(int weightClassId) { this.weightClassId = weightClassId; }
    
    public double getRankingScore() { return rankingScore; }
    public void setRankingScore(double rankingScore) { this.rankingScore = rankingScore; }
    
    public int getExperience() { return experience; }
    
    public String getProfileImage() { return profileImage; }
    public void setProfileImage(String profileImage) { this.profileImage = profileImage; }
    
    // Calcul du taux de victoire
    public double getWinRate() {
        int total = wins + losses + draws;
        return total > 0 ? (double) wins / total * 100 : 0;
    }
    
    // Record formaté (W-L-D)
    public String getRecord() {
        return wins + "-" + losses + "-" + draws;
    }
    
    @Override
    public String toString() {
        return getFullName() + " (" + getRecord() + ")";
    }
}
