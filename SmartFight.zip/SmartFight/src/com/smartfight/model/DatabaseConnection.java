package com.smartfight.model;

public class DatabaseConnection {

	public static boolean testConnection() {
		// TODO Auto-generated method stub
		return false;
	}

}
