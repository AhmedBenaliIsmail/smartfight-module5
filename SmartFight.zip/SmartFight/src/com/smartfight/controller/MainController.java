package com.smartfight.controller;

import com.smartfight.model.Fighter;
import javafx.application.Platform;
import javafx.collections.transformation.FilteredList;
import com.smartfight.model.MatchProposal;
import com.smartfight.model.Ranking;
import com.smartfight.service.SmartFightService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.List;

public class MainController {
    private SmartFightService service;

    private ObservableList<Fighter> fighters;
    private ObservableList<MatchProposal> matchProposals;
    private ObservableList<Ranking> rankings;
    private FilteredList<Ranking> filteredRankings;

    public MainController() {
        try {
            this.service = new SmartFightService();
            this.fighters = FXCollections.observableArrayList();
            this.matchProposals = FXCollections.observableArrayList();
            this.rankings = FXCollections.observableArrayList();
            this.filteredRankings = new FilteredList<>(rankings, r -> true);
            System.out.println("✓ MainController initialisé avec succès");
        } catch (Exception e) {
            System.err.println("❌ Erreur lors de l'initialisation du contrôleur: " + e.getMessage());
            throw new RuntimeException("Impossible d'initialiser le contrôleur", e);
        }
    }

    public ObservableList<Ranking> getRankings() {
        return filteredRankings;
    }

    // ===== GESTION DES COMBATTANTS =====

    public void loadAllFighters() {
        try {
            List<Fighter> fighterList = service.getAllFighters();
            // ✅ Platform.runLater garantit la mise à jour sur le thread JavaFX
            Platform.runLater(() -> {
                if (fighterList != null) {
                    fighters.setAll(fighterList);
                    System.out.println("✓ " + fighterList.size() + " combattants chargés");
                } else {
                    fighters.clear();
                    System.out.println("⚠️ Aucun combattant trouvé");
                }
            });
        } catch (Exception e) {
            System.err.println("❌ Erreur lors du chargement des combattants: " + e.getMessage());
            e.printStackTrace();
            Platform.runLater(() -> fighters.clear());
        }
    }

    public void loadFightersByWeightClass(int weightClassId) {
        try {
            if (weightClassId <= 0) {
                loadAllFighters();
                return;
            }
            List<Fighter> fighterList = service.getFightersByWeightClass(weightClassId);
            Platform.runLater(() -> {
                if (fighterList != null) {
                    fighters.setAll(fighterList);
                } else {
                    fighters.clear();
                }
            });
        } catch (Exception e) {
            System.err.println("❌ Erreur chargement par catégorie: " + e.getMessage());
            Platform.runLater(() -> fighters.clear());
        }
    }

    public void searchFighters(String searchTerm) {
        try {
            if (searchTerm == null || searchTerm.trim().isEmpty()) {
                loadAllFighters();
                return;
            }
            List<Fighter> fighterList = service.searchFighters(searchTerm.trim());
            Platform.runLater(() -> {
                if (fighterList != null) {
                    fighters.setAll(fighterList);
                } else {
                    fighters.clear();
                }
            });
        } catch (Exception e) {
            System.err.println("❌ Erreur recherche: " + e.getMessage());
            Platform.runLater(() -> fighters.clear());
        }
    }

    /**
     * ✅ saveFighter : sauvegarde puis recharge automatiquement la liste
     */
    public boolean saveFighter(Fighter fighter) {
        try {
            if (fighter == null) return false;
            if (fighter.getName() == null || fighter.getName().trim().isEmpty()) {
                System.err.println("⚠️ Le nom du combattant est requis");
                return false;
            }

            boolean success = service.saveFighter(fighter);

            if (success) {
                // ✅ Rechargement immédiat sur le thread JavaFX après sauvegarde
                List<Fighter> updatedList = service.getAllFighters();
                Platform.runLater(() -> {
                    if (updatedList != null) {
                        fighters.setAll(updatedList);
                    }
                });
                System.out.println("✓ Combattant enregistré + liste rechargée: " + fighter.getName());
            }
            return success;

        } catch (Exception e) {
            System.err.println("❌ Erreur enregistrement combattant: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * ✅ deleteFighter : supprime puis recharge automatiquement la liste
     */
    public boolean deleteFighter(int id) {
        try {
            if (id <= 0) return false;

            boolean success = service.deleteFighter(id);

            if (success) {
                // ✅ Rechargement immédiat sur le thread JavaFX après suppression
                List<Fighter> updatedList = service.getAllFighters();
                Platform.runLater(() -> {
                    if (updatedList != null) {
                        fighters.setAll(updatedList);
                    }
                });
                System.out.println("✓ Combattant #" + id + " supprimé + liste rechargée");
            }
            return success;

        } catch (Exception e) {
            System.err.println("❌ Erreur suppression combattant: " + e.getMessage());
            return false;
        }
    }

    public ObservableList<Fighter> getFighters() {
        return fighters;
    }

    // ===== MATCHMAKING =====

    public void generateMatches(int maxMatches) {
        try {
            if (maxMatches <= 0) return;
            List<MatchProposal> proposals = service.generateMatches(maxMatches);
            Platform.runLater(() -> {
                if (proposals != null) {
                    matchProposals.setAll(proposals);
                } else {
                    matchProposals.clear();
                }
            });
        } catch (Exception e) {
            System.err.println("❌ Erreur génération matchs: " + e.getMessage());
            Platform.runLater(() -> matchProposals.clear());
        }
    }

    public void generateMatchesForWeightClass(int weightClassId, int maxMatches) {
        try {
            if (weightClassId <= 0 || maxMatches <= 0) return;
            List<MatchProposal> proposals = service.generateMatchesForWeightClass(weightClassId, maxMatches);
            Platform.runLater(() -> {
                if (proposals != null) {
                    matchProposals.setAll(proposals);
                } else {
                    matchProposals.clear();
                }
            });
        } catch (Exception e) {
            System.err.println("❌ Erreur génération matchs par catégorie: " + e.getMessage());
            Platform.runLater(() -> matchProposals.clear());
        }
    }

    public MatchProposal findBestOpponent(int fighterId) {
        try {
            if (fighterId <= 0) return null;
            return service.findBestOpponent(fighterId);
        } catch (Exception e) {
            System.err.println("❌ Erreur recherche adversaire: " + e.getMessage());
            return null;
        }
    }

    public ObservableList<MatchProposal> getMatchProposals() {
        return matchProposals;
    }

    // ===== CLASSEMENTS =====

    public void loadAllRankings() {
        try {
            List<Ranking> rankingList = service.getAllRankings();
            Platform.runLater(() -> {
                if (rankingList != null) {
                    rankings.setAll(rankingList);
                } else {
                    rankings.clear();
                }
            });
        } catch (Exception e) {
            Platform.runLater(() -> rankings.clear());
        }
    }

    public void loadRankingsByWeightClass(int weightClassId) {
        try {
            List<Ranking> rankingList = service.getRankingsByWeightClass(weightClassId);
            Platform.runLater(() -> {
                if (rankingList != null) {
                    rankings.setAll(rankingList);
                } else {
                    rankings.clear();
                }
            });
        } catch (Exception e) {
            Platform.runLater(() -> rankings.clear());
        }
    }

    public void filterRankingsByName(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            filteredRankings.setPredicate(r -> true);
        } else {
            String lowerSearch = searchTerm.toLowerCase();
            filteredRankings.setPredicate(r ->
                r.getFighterName() != null &&
                r.getFighterName().toLowerCase().contains(lowerSearch)
            );
        }
    }

    public void recalculateRankings(int weightClassId) {
        try {
            if (weightClassId <= 0) return;
            List<Ranking> rankingList = service.recalculateRankings(weightClassId);
            Platform.runLater(() -> {
                if (rankingList != null) {
                    rankings.setAll(rankingList);
                }
            });
        } catch (Exception e) {
            System.err.println("❌ Erreur recalcul classements: " + e.getMessage());
        }
    }

    public boolean initializeRankings(int weightClassId) {
        try {
            if (weightClassId <= 0) return false;
            boolean success = service.initializeRankings(weightClassId);
            if (success) {
                loadRankingsByWeightClass(weightClassId);
            }
            return success;
        } catch (Exception e) {
            System.err.println("❌ Erreur initialisation classements: " + e.getMessage());
            return false;
        }
    }

    // ===== STATISTIQUES =====

    public SmartFightService.SmartFightStats getStats() {
        try {
            SmartFightService.SmartFightStats stats = service.getStats();
            return stats != null ? stats : new SmartFightService.SmartFightStats();
        } catch (Exception e) {
            System.err.println("❌ Erreur stats: " + e.getMessage());
            return new SmartFightService.SmartFightStats();
        }
    }

    // ===== UTILITAIRES =====

    public Fighter getFighterById(int id) {
        try {
            if (id <= 0) return null;
            return service.getFighterById(id);
        } catch (Exception e) {
            System.err.println("❌ Erreur getFighterById #" + id + ": " + e.getMessage());
            return null;
        }
    }

    public double calculateMatchScore(int fighter1Id, int fighter2Id) {
        try {
            if (fighter1Id <= 0 || fighter2Id <= 0 || fighter1Id == fighter2Id) return 0.0;
            return service.calculateMatchScore(fighter1Id, fighter2Id);
        } catch (Exception e) {
            System.err.println("❌ Erreur calcul score: " + e.getMessage());
            return 0.0;
        }
    }

    public void dispose() {
        try {
            fighters.clear();
            matchProposals.clear();
            rankings.clear();
            System.out.println("✓ Ressources du contrôleur libérées");
        } catch (Exception e) {
            System.err.println("⚠️ Erreur nettoyage: " + e.getMessage());
        }
    }
}