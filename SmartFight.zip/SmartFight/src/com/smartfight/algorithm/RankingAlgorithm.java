package com.smartfight.algorithm;

import com.smartfight.model.Fighter;
import com.smartfight.model.Ranking;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Algorithme de calcul du classement dynamique des combattants
 * 
 * Le score de classement est calculé selon la formule ELO modifiée :
 * Score = BaseScore + VictoryBonus + ActivityBonus - InactivityPenalty
 * 
 * Facteurs pris en compte :
 * - Nombre de victoires et défaites (avec pondération récente)
 * - Qualité des adversaires battus
 * - Séries de victoires
 * - Activité récente
 * - Performance globale
 */
public class RankingAlgorithm {
    
    // Constantes pour le calcul
    private static final double BASE_SCORE = 1000.0;
    private static final double K_FACTOR = 32.0; // Facteur de variation ELO
    private static final double WIN_BONUS = 50.0;
    private static final double LOSS_PENALTY = 30.0;
    private static final double STREAK_MULTIPLIER = 1.2;
    private static final double DOMINANCE_BONUS = 20.0; // Bonus pour victoire dominante
    
    /**
     * Calcule les classements pour une liste de combattants d'une même catégorie
     * 
     * @param fighters Liste des combattants à classer
     * @param weightClassId ID de la catégorie de poids
     * @return Liste des classements triée par score
     */
    public List<Ranking> calculateRankings(List<Fighter> fighters, int weightClassId) {
        List<Ranking> rankings = new ArrayList<>();
        
        // Calculer le score de chaque combattant
        for (Fighter fighter : fighters) {
            double score = calculateFighterScore(fighter, fighters);
            
            Ranking ranking = new Ranking();
            ranking.setFighterId(fighter.getId());
            ranking.setWeightClassId(weightClassId);
            ranking.setScore(score);
            ranking.setLastUpdated(LocalDate.now());
            ranking.setFighter(fighter);
            
            rankings.add(ranking);
        }
        
        // Trier par score décroissant
        rankings = rankings.stream()
            .sorted((r1, r2) -> Double.compare(r2.getScore(), r1.getScore()))
            .collect(Collectors.toList());
        
        // Attribuer les rangs
        for (int i = 0; i < rankings.size(); i++) {
            rankings.get(i).setRank(i + 1);
        }
        
        return rankings;
    }
    
    /**
     * Calcule le score d'un combattant
     */
    public double calculateFighterScore(Fighter fighter, List<Fighter> allFighters) {
        double score = BASE_SCORE;
        
        // 1. Score basé sur le ratio victoires/défaites
        score += calculateWinLossScore(fighter);
        
        // 2. Bonus de série de victoires
        score += calculateStreakBonus(fighter);
        
        // 3. Bonus basé sur la qualité des adversaires
        score += calculateOpponentQualityBonus(fighter, allFighters);
        
        // 4. Bonus d'activité
        score += calculateActivityBonus(fighter);
        
        // 5. Bonus de dominance (taux de victoire)
        score += calculateDominanceBonus(fighter);
        
        return Math.max(0, score);
    }
    
    /**
     * Score basé sur les victoires et défaites
     */
    private double calculateWinLossScore(Fighter fighter) {
        int wins = fighter.getWins();
        int losses = fighter.getLosses();
        
        double winScore = wins * WIN_BONUS;
        double lossScore = losses * LOSS_PENALTY;
        
        return winScore - lossScore;
    }
    
    /**
     * Bonus pour les séries de victoires
     */
    private double calculateStreakBonus(Fighter fighter) {
        double winRate = fighter.getWinRate();
        
        // Si le combattant a un bon taux de victoire, bonus de série
        if (winRate >= 75 && fighter.getWins() >= 3) {
            return WIN_BONUS * STREAK_MULTIPLIER * (fighter.getWins() / 3.0);
        } else if (winRate >= 60 && fighter.getWins() >= 2) {
            return WIN_BONUS * (fighter.getWins() / 4.0);
        }
        
        return 0;
    }
    
    /**
     * Bonus basé sur la qualité des adversaires battus
     * (Simplifié - dans une version complète, on analyserait l'historique des combats)
     */
    private double calculateOpponentQualityBonus(Fighter fighter, List<Fighter> allFighters) {
        // Bonus si le combattant a battu des adversaires de qualité
        // Ici on utilise une heuristique simple : si le taux de victoire est élevé
        // contre des adversaires expérimentés
        
        double avgOpponentExperience = allFighters.stream()
            .filter(f -> f.getId() != fighter.getId())
            .mapToInt(Fighter::getExperience)
            .average()
            .orElse(0);
        
        if (fighter.getExperience() >= avgOpponentExperience && fighter.getWinRate() > 50) {
            return DOMINANCE_BONUS * (fighter.getWinRate() / 100.0);
        }
        
        return 0;
    }
    
    /**
     * Bonus d'activité (favorise les combattants actifs)
     */
    private double calculateActivityBonus(Fighter fighter) {
        int totalFights = fighter.getExperience();
        
        // Bonus pour les combattants actifs
        if (totalFights >= 20) {
            return 100;
        } else if (totalFights >= 10) {
            return 50;
        } else if (totalFights >= 5) {
            return 25;
        }
        
        return 0;
    }
    
    /**
     * Bonus de dominance basé sur le taux de victoire
     */
    private double calculateDominanceBonus(Fighter fighter) {
        double winRate = fighter.getWinRate();
        
        if (winRate >= 90) {
            return DOMINANCE_BONUS * 3;
        } else if (winRate >= 80) {
            return DOMINANCE_BONUS * 2;
        } else if (winRate >= 70) {
            return DOMINANCE_BONUS;
        }
        
        return 0;
    }
    
    /**
     * Met à jour le classement après un combat
     * Utilise une variation de l'algorithme ELO
     */
    public void updateRankingAfterFight(Ranking winnerRanking, Ranking loserRanking, 
                                       boolean wasDominant) {
        double winnerScore = winnerRanking.getScore();
        double loserScore = loserRanking.getScore();
        
        // Calcul de la probabilité de victoire attendue (ELO)
        double expectedWinner = 1.0 / (1.0 + Math.pow(10, (loserScore - winnerScore) / 400.0));
        double expectedLoser = 1.0 - expectedWinner;
        
        // Nouveau score (avec bonus de dominance si applicable)
        double kFactor = K_FACTOR;
        if (wasDominant) {
            kFactor *= 1.5; // Augmente le changement pour une victoire dominante
        }
        
        double newWinnerScore = winnerScore + kFactor * (1.0 - expectedWinner);
        double newLoserScore = loserScore + kFactor * (0.0 - expectedLoser);
        
        winnerRanking.setScore(newWinnerScore);
        loserRanking.setScore(Math.max(BASE_SCORE / 2, newLoserScore)); // Score minimum
        
        winnerRanking.setLastUpdated(LocalDate.now());
        loserRanking.setLastUpdated(LocalDate.now());
    }
    
    /**
     * Recalcule tous les classements d'une catégorie de poids
     */
    public List<Ranking> recalculateAllRankings(List<Fighter> fighters, 
                                                List<Ranking> currentRankings, 
                                                int weightClassId) {
        // Sauvegarder les rangs précédents
        for (Ranking ranking : currentRankings) {
            ranking.setPreviousRank(ranking.getRank());
        }
        
        // Recalculer les nouveaux classements
        List<Ranking> newRankings = calculateRankings(fighters, weightClassId);
        
        // Transférer les IDs et rangs précédents
        for (Ranking newRanking : newRankings) {
            for (Ranking oldRanking : currentRankings) {
                if (newRanking.getFighterId() == oldRanking.getFighterId()) {
                    newRanking.setId(oldRanking.getId());
                    newRanking.setPreviousRank(oldRanking.getRank());
                    break;
                }
            }
        }
        
        return newRankings;
    }
    
    /**
     * Obtient les combattants du top N
     */
    public List<Fighter> getTopRankedFighters(List<Ranking> rankings, int topN) {
        return rankings.stream()
            .limit(topN)
            .map(Ranking::getFighter)
            .filter(f -> f != null)
            .collect(Collectors.toList());
    }
}
