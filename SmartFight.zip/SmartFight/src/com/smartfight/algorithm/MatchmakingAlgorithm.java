package com.smartfight.algorithm;

import com.smartfight.model.Fighter;
import com.smartfight.model.MatchProposal;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Algorithme intelligent de matchmaking pour créer des combats équilibrés
 * 
 * L'algorithme prend en compte plusieurs facteurs :
 * - Catégorie de poids (obligatoire)
 * - Niveau d'expérience (nombre de combats)
 * - Taux de victoire
 * - Classement actuel
 * - Série de victoires/défaites
 */
public class MatchmakingAlgorithm {
    
    // Poids des différents critères (total = 1.0)
    private static final double WEIGHT_EXPERIENCE = 0.25;
    private static final double WEIGHT_WIN_RATE = 0.30;
    private static final double WEIGHT_RANKING = 0.25;
    private static final double WEIGHT_STREAK = 0.20;
    
    // Seuils de compatibilité
    private static final int MAX_EXPERIENCE_DIFF = 8;
    private static final double MAX_WIN_RATE_DIFF = 25.0;
    
    /**
     * Génère les meilleurs matchs pour une liste de combattants
     * 
     * @param fighters Liste des combattants disponibles
     * @param maxMatches Nombre maximum de matchs à générer
     * @return Liste des propositions de match triée par score
     */
    public List<MatchProposal> generateMatches(List<Fighter> fighters, int maxMatches) {
        List<MatchProposal> proposals = new ArrayList<>();
        
        // ← Compare TOUS les combattants entre eux (sans filtrer par catégorie)
        for (int i = 0; i < fighters.size(); i++) {
            for (int j = i + 1; j < fighters.size(); j++) {
                Fighter f1 = fighters.get(i);
                Fighter f2 = fighters.get(j);
                
                double matchScore = calculateMatchScore(f1, f2);
                
                // Accepter tous les matchs avec score > 0
                if (matchScore > 0) {
                    MatchProposal proposal = new MatchProposal(f1, f2, matchScore);
                    proposal.setReasoning(generateMatchReasoning(f1, f2, matchScore));
                    proposals.add(proposal);
                }
            }
        }
        
        // Trier par score décroissant et limiter au nombre demandé
        return proposals.stream()
            .sorted((m1, m2) -> Double.compare(m2.getMatchScore(), m1.getMatchScore()))
            .limit(maxMatches)
            .collect(Collectors.toList());
    }
    
    /**
     * Génère les matchs pour une catégorie de poids spécifique
     */
    private List<MatchProposal> generateMatchesForWeightClass(List<Fighter> fighters, int weightClassId) {
        List<MatchProposal> proposals = new ArrayList<>();
        
        // Comparer chaque paire de combattants
        for (int i = 0; i < fighters.size(); i++) {
            for (int j = i + 1; j < fighters.size(); j++) {
                Fighter f1 = fighters.get(i);
                Fighter f2 = fighters.get(j);
                
                // Calculer le score de compatibilité
                double matchScore = calculateMatchScore(f1, f2);
                
                // Si le match est acceptable (score > 50)
                if (matchScore >= 50) {
                    MatchProposal proposal = new MatchProposal(f1, f2, matchScore);
                    proposal.setWeightClassId(weightClassId);
                    proposal.setReasoning(generateMatchReasoning(f1, f2, matchScore));
                    proposals.add(proposal);
                }
            }
        }
        
        return proposals;
    }
    
    /**
     * Calcule le score de qualité d'un match entre deux combattants
     * Score de 0 à 100 (100 = match parfait)
     */
    public double calculateMatchScore(Fighter f1, Fighter f2) {
        double score = 0;
        
        // 1. Score d'expérience (25%)
        score += calculateExperienceScore(f1, f2) * WEIGHT_EXPERIENCE;
        
        // 2. Score de taux de victoire (30%)
        score += calculateWinRateScore(f1, f2) * WEIGHT_WIN_RATE;
        
        // 3. Score de classement (25%)
        score += calculateRankingScore(f1, f2) * WEIGHT_RANKING;
        
        // 4. Score de série (20%)
        score += calculateStreakScore(f1, f2) * WEIGHT_STREAK;
        
        return Math.min(100, Math.max(0, score));
    }
    
    /**
     * Score basé sur la différence d'expérience
     */
    private double calculateExperienceScore(Fighter f1, Fighter f2) {
        int exp1 = f1.getExperience();
        int exp2 = f2.getExperience();
        int diff = Math.abs(exp1 - exp2);
        
        if (diff > MAX_EXPERIENCE_DIFF) {
            return 0; // Trop de différence
        }
        
        // Plus la différence est faible, meilleur est le score
        return 100 * (1 - (double) diff / MAX_EXPERIENCE_DIFF);
    }
    
    /**
     * Score basé sur la différence de taux de victoire
     */
    private double calculateWinRateScore(Fighter f1, Fighter f2) {
        double wr1 = f1.getWinRate();
        double wr2 = f2.getWinRate();
        double diff = Math.abs(wr1 - wr2);
        
        if (diff > MAX_WIN_RATE_DIFF) {
            return 0; // Trop de différence
        }
        
        // Plus la différence est faible, meilleur est le score
        return 100 * (1 - diff / MAX_WIN_RATE_DIFF);
    }
    
    /**
     * Score basé sur les classements
     */
    private double calculateRankingScore(Fighter f1, Fighter f2) {
        double rank1 = f1.getRankingScore();
        double rank2 = f2.getRankingScore();
        
        // Si pas de classement, score neutre
        if (rank1 == 0 || rank2 == 0) {
            return 50;
        }
        
        double diff = Math.abs(rank1 - rank2);
        double maxDiff = Math.max(rank1, rank2);
        
        if (maxDiff == 0) return 100;
        
        // Score inversement proportionnel à la différence
        return 100 * (1 - Math.min(1, diff / maxDiff));
    }
    
    /**
     * Score basé sur les séries de victoires/défaites récentes
     */
    private double calculateStreakScore(Fighter f1, Fighter f2) {
        // Combattants en série de victoires vs combattants en difficulté
        boolean f1OnStreak = f1.getWins() > 0 && f1.getWinRate() > 60;
        boolean f2OnStreak = f2.getWins() > 0 && f2.getWinRate() > 60;
        
        // Match équilibré si les deux ont des séries similaires
        if (f1OnStreak == f2OnStreak) {
            return 100;
        }
        
        // Sinon, score moyen
        return 60;
    }
    
    /**
     * Génère une explication textuelle du match
     */
    private String generateMatchReasoning(Fighter f1, Fighter f2, double score) {
        StringBuilder reasoning = new StringBuilder();
        
        reasoning.append("Match Quality Score: ").append(String.format("%.1f", score)).append("/100\n");
        reasoning.append("\n");
        
        // Expérience
        int expDiff = Math.abs(f1.getExperience() - f2.getExperience());
        reasoning.append("✓ Experience: ");
        if (expDiff <= 2) {
            reasoning.append("Very balanced (").append(expDiff).append(" fights difference)\n");
        } else if (expDiff <= 5) {
            reasoning.append("Balanced (").append(expDiff).append(" fights difference)\n");
        } else {
            reasoning.append("Moderate difference (").append(expDiff).append(" fights)\n");
        }
        
        // Taux de victoire
        double wrDiff = Math.abs(f1.getWinRate() - f2.getWinRate());
        reasoning.append("✓ Win Rate: ");
        if (wrDiff <= 10) {
            reasoning.append("Excellent match (").append(String.format("%.1f", wrDiff)).append("% difference)\n");
        } else if (wrDiff <= 20) {
            reasoning.append("Good match (").append(String.format("%.1f", wrDiff)).append("% difference)\n");
        } else {
            reasoning.append("Fair match (").append(String.format("%.1f", wrDiff)).append("% difference)\n");
        }
        
        // Records
        reasoning.append("✓ Records: ")
                .append(f1.getFullName()).append(" (").append(f1.getRecord()).append(") vs ")
                .append(f2.getFullName()).append(" (").append(f2.getRecord()).append(")\n");
        
        // Type de match suggéré
        reasoning.append("\n");
        if (score >= 90) {
            reasoning.append("Recommended: Main Event or Title Fight");
        } else if (score >= 75) {
            reasoning.append("Recommended: Co-Main Event");
        } else {
            reasoning.append("Recommended: Undercard");
        }
        
        return reasoning.toString();
    }
    
    /**
     * Trouve le meilleur adversaire pour un combattant donné
     */
    public MatchProposal findBestOpponent(Fighter fighter, List<Fighter> availableFighters) {
        MatchProposal bestMatch = null;
        double bestScore = 0;
        
        for (Fighter opponent : availableFighters) {
            // Ne pas se matcher avec soi-même
            if (opponent.getId() == fighter.getId()) continue;
            
            
            double score = calculateMatchScore(fighter, opponent);
            
            if (score > bestScore) {
                bestScore = score;
                bestMatch = new MatchProposal(fighter, opponent, score);
                bestMatch.setReasoning(generateMatchReasoning(fighter, opponent, score));
            }
        }
        
        return bestMatch;
    }
}
