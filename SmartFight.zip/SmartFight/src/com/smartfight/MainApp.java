package com.smartfight;

import com.smartfight.model.DatabaseConnection;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.image.Image; 
import com.smartfight.view.MainView;
import javafx.stage.Stage;

public class MainApp extends Application {

    private static final String APP_TITLE = "SmartFight - AI Matchmaking & Rankings";
    private static final double DEFAULT_WIDTH = 1280;
    private static final double DEFAULT_HEIGHT = 800;
    private static final double MIN_WIDTH = 900;
    private static final double MIN_HEIGHT = 600;

    private MainView mainView;

    public void start(Stage primaryStage) {
        try {
            // ── 1. Test connexion DB ──────────────────────────────────────
            if (!DatabaseConnection.testConnection()) {
                System.err.println("⚠ AVERTISSEMENT: Impossible de se connecter à la base de données");
                System.err.println("Vérifiez que MySQL est lancé et que les paramètres sont corrects");

                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Problème de connexion");
                    alert.setHeaderText("Base de données non disponible");
                    alert.setContentText(
                        "L'application ne peut pas se connecter à la base de données.\n\n" +
                        "Vérifiez que :\n" +
                        "• MySQL est démarré\n" +
                        "• Les identifiants de connexion sont corrects\n" +
                        "• La base de données 'smartfight' existe\n\n" +
                        "L'application continuera mais certaines fonctionnalités seront limitées."
                    );
                    alert.showAndWait();
                });
            }

            // ── 2. Créer la vue principale ────────────────────────────────
            mainView = new MainView();
            Scene scene = new Scene(mainView.getRoot(), DEFAULT_WIDTH, DEFAULT_HEIGHT);

            // ── 3. Charger le CSS si disponible ──────────────────────────
            try {
                String cssPath = getClass()
                    .getResource("/css/style.css")
                    .toExternalForm();
                scene.getStylesheets().add(cssPath);
                System.out.println("✓ CSS chargé");
            } catch (Exception e) {
                System.out.println("ℹ Fichier CSS non trouvé, utilisation du style par défaut");
            }

            // ── 4. Configuration de la fenêtre ────────────────────────────
            primaryStage.setTitle(APP_TITLE);
            primaryStage.setScene(scene);
            primaryStage.setMinWidth(MIN_WIDTH);
            primaryStage.setMinHeight(MIN_HEIGHT);

            // ── 5. Charger l'icône si disponible ─────────────────────────
            try {
                Image icon = new Image(
                    getClass().getResourceAsStream("/images/logo.png")
                );
                if (!icon.isError()) {
                    primaryStage.getIcons().add(icon);
                    System.out.println("✓ Icône chargée");
                }
            } catch (Exception e) {
                System.out.println("ℹ Icône de l'application non trouvée");
            }

            // ── 6. Gérer la fermeture proprement ─────────────────────────
            primaryStage.setOnCloseRequest(event -> {
                System.out.println("🟢 Fermeture de l'application...");
                if (mainView != null) {
                    mainView.dispose(); // libère les ressources de MainView
                }
                stop();
            });

            primaryStage.show();
            System.out.println("✓ Application démarrée avec succès");

        } catch (Exception e) {
            System.err.println("❌ Erreur critique au démarrage: " + e.getMessage());
            e.printStackTrace();

            // Alerte critique si l'appli ne peut pas démarrer
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur critique");
            alert.setHeaderText("Impossible de démarrer l'application");
            alert.setContentText(e.getMessage());
            alert.showAndWait();

            Platform.exit();
        }
    }

    @Override
    public void stop() {
        try {
            DatabaseConnection.testConnection();
            System.out.println("✓ Connexion DB fermée");
        } catch (Exception e) {
            System.err.println("⚠ Erreur lors de la fermeture DB: " + e.getMessage());
        }
        Platform.exit();
        System.exit(0);
    }

    public static void main(String[] args) {
        launch(args);
    }
}