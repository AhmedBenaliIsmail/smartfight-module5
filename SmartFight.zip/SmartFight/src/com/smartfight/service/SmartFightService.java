package com.smartfight.service;

import com.smartfight.algorithm.MatchmakingAlgorithm;
import com.smartfight.algorithm.RankingAlgorithm;
import com.smartfight.dao.FighterDAO;
import com.smartfight.dao.RankingDAO;
import com.smartfight.model.Fighter;
import com.smartfight.model.MatchProposal;
import com.smartfight.model.Ranking;

import java.util.List;

/**
 * Service principal pour la gestion du matchmaking et des classements
 */
public class SmartFightService {
    private FighterDAO fighterDAO;
    private RankingDAO rankingDAO;
    private MatchmakingAlgorithm matchmakingAlgorithm;
    private RankingAlgorithm rankingAlgorithm;
    
    public SmartFightService() {
        this.fighterDAO = new FighterDAO();
        this.rankingDAO = new RankingDAO();
        this.matchmakingAlgorithm = new MatchmakingAlgorithm();
        this.rankingAlgorithm = new RankingAlgorithm();
    }
    
    // ===== GESTION DES COMBATTANTS =====
    
    public List<Fighter> getAllFighters() {
        return fighterDAO.getAllFighters();
    }
    
    public Fighter getFighterById(int id) {
        return fighterDAO.getFighterById(id);
    }
    
    public List<Fighter> getFightersByWeightClass(int weightClassId) {
        return fighterDAO.getFightersByWeightClass(weightClassId);
    }
    
    public List<Fighter> searchFighters(String searchTerm) {
        return fighterDAO.searchFighters(searchTerm);
    }
    
    public boolean saveFighter(Fighter fighter) {
        if (fighter.getId() == 0) {
            return fighterDAO.addFighter(fighter);
        } else {
            return fighterDAO.updateFighter(fighter);
        }
    }
    
    public boolean deleteFighter(int id) {
        return fighterDAO.deleteFighter(id);
    }
    
    // ===== MATCHMAKING =====
    
    /**
     * Génère automatiquement les meilleurs matchs
     */
    public List<MatchProposal> generateMatches(int maxMatches) {
        List<Fighter> allFighters = fighterDAO.getAllFighters();
        return matchmakingAlgorithm.generateMatches(allFighters, maxMatches);
    }
    
    /**
     * Génère des matchs pour une catégorie de poids spécifique
     */
    public List<MatchProposal> generateMatchesForWeightClass(int weightClassId, int maxMatches) {
        // ← weightClassId correspond en réalité à discipline_id dans ta table
        List<Fighter> fighters = fighterDAO.getFightersByDiscipline(weightClassId);
        return matchmakingAlgorithm.generateMatches(fighters, maxMatches);
    }
    
    /**
     * Trouve le meilleur adversaire pour un combattant
     */
    public MatchProposal findBestOpponent(int fighterId) {
        Fighter fighter = fighterDAO.getFighterById(fighterId);
        if (fighter == null) return null;
        
        // ← Utilise getAllFighters() car weight_class_id n'existe pas dans ta table
        // L'algorithme filtrera par discipline via getWeightClassId() qui mappe discipline_id
        List<Fighter> availableFighters = fighterDAO.getAllFighters();
        return matchmakingAlgorithm.findBestOpponent(fighter, availableFighters);
    }
    
    /**
     * Calcule le score de qualité entre deux combattants
     */
    public double calculateMatchScore(int fighter1Id, int fighter2Id) {
        Fighter f1 = fighterDAO.getFighterById(fighter1Id);
        Fighter f2 = fighterDAO.getFighterById(fighter2Id);
        
        if (f1 == null || f2 == null) return 0;
        
        return matchmakingAlgorithm.calculateMatchScore(f1, f2);
    }
    
    // ===== CLASSEMENTS =====
    
    /**
     * Récupère tous les classements
     */
    public List<Ranking> getAllRankings() {
        return rankingDAO.getAllRankings();
    }
    
    /**
     * Récupère les classements par catégorie de poids
     */
    public List<Ranking> getRankingsByWeightClass(int weightClassId) {
        List<Ranking> rankings = rankingDAO.getRankingsByWeightClass(weightClassId);
        
        // Charger les informations des combattants
        for (Ranking ranking : rankings) {
            Fighter fighter = fighterDAO.getFighterById(ranking.getFighterId());
            ranking.setFighter(fighter);
        }
        
        return rankings;
    }
    
    /**
     * Récupère le classement d'un combattant
     */
    public Ranking getFighterRanking(int fighterId) {
        Ranking ranking = rankingDAO.getRankingByFighter(fighterId);
        if (ranking != null) {
            Fighter fighter = fighterDAO.getFighterById(fighterId);
            ranking.setFighter(fighter);
        }
        return ranking;
    }
    
    /**
     * Recalcule les classements d'une catégorie de poids
     */
    public List<Ranking> recalculateRankings(int weightClassId) {
        List<Fighter> fighters = fighterDAO.getFightersByWeightClass(weightClassId);
        List<Ranking> currentRankings = rankingDAO.getRankingsByWeightClass(weightClassId);
        
        // Calculer les nouveaux classements
        List<Ranking> newRankings = rankingAlgorithm.recalculateAllRankings(
            fighters, currentRankings, weightClassId
        );
        
        // Sauvegarder dans la base de données
        for (Ranking ranking : newRankings) {
            rankingDAO.saveRanking(ranking);
        }
        
        return newRankings;
    }
    
    /**
     * Calcule et sauvegarde les classements pour tous les combattants d'une catégorie
     */
    public boolean initializeRankings(int weightClassId) {
        try {
            // Supprimer les anciens classements
            rankingDAO.deleteRankingsByWeightClass(weightClassId);
            
            // Calculer les nouveaux
            List<Ranking> rankings = recalculateRankings(weightClassId);
            
            return !rankings.isEmpty();
        } catch (Exception e) {
            System.err.println("Erreur lors de l'initialisation des classements");
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Met à jour les classements après un combat
     */
    public void updateRankingsAfterFight(int winnerId, int loserId, boolean wasDominant) {
        Ranking winnerRanking = rankingDAO.getRankingByFighter(winnerId);
        Ranking loserRanking = rankingDAO.getRankingByFighter(loserId);
        
        if (winnerRanking != null && loserRanking != null) {
            rankingAlgorithm.updateRankingAfterFight(winnerRanking, loserRanking, wasDominant);
            
            rankingDAO.saveRanking(winnerRanking);
            rankingDAO.saveRanking(loserRanking);
            
            // Recalculer tous les rangs de la catégorie
            recalculateRankings(winnerRanking.getWeightClassId());
        }
    }
    
    /**
     * Obtient les statistiques générales
     */
    public SmartFightStats getStats() {
        List<Fighter> fighters = fighterDAO.getAllFighters();
        List<Ranking> rankings = rankingDAO.getAllRankings();
        
        return new SmartFightStats(
            fighters.size(),
            rankings.size(),
            fighters.stream().mapToInt(Fighter::getWins).sum(),
            0 // Nombre de matchs proposés (à implémenter avec MatchProposalDAO)
        );
    }
    
    /**
     * Classe interne pour les statistiques
     */
    public static class SmartFightStats {
        public final int totalFighters;
        public final int totalRankings;
        public final int totalWins;
        public final int totalMatchProposals;
        
        // ← AJOUTE CE CONSTRUCTEUR VIDE
        public SmartFightStats() {
            this.totalFighters = 0;
            this.totalRankings = 0;
            this.totalWins = 0;
            this.totalMatchProposals = 0;
        }
        
        // Garde le constructeur existant
        public SmartFightStats(int totalFighters, int totalRankings, 
                              int totalWins, int totalMatchProposals) {
            this.totalFighters = totalFighters;
            this.totalRankings = totalRankings;
            this.totalWins = totalWins;
            this.totalMatchProposals = totalMatchProposals;
        }
    }
}
