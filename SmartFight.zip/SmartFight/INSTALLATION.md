# 🚀 Guide d'Installation Rapide - SmartFight

## ⚡ Installation en 10 Minutes

### 1️⃣ Prérequis (À télécharger si vous ne les avez pas)

✅ **Java JDK 11+**
- Lien: https://www.oracle.com/java/technologies/downloads/
- Vérifier l'installation: `java -version` dans le terminal

✅ **Eclipse IDE**
- Lien: https://www.eclipse.org/downloads/
- Version recommandée: Eclipse IDE for Java Developers

✅ **MySQL Server**
- Lien: https://dev.mysql.com/downloads/
- N'oubliez pas de noter votre mot de passe root !

✅ **MySQL Connector/J**
- Lien: https://dev.mysql.com/downloads/connector/j/
- Télécharger le fichier JAR

✅ **JavaFX SDK**
- Vous avez déjà: javafx-sdk-25.0.2 ✓

---

## 2️⃣ Configuration Étape par Étape

### ÉTAPE A: Configurer JavaFX dans Eclipse

1. Ouvrir Eclipse
2. Menu: **Window → Preferences**
3. Navigation: **Java → Build Path → User Libraries**
4. Cliquer: **New**
5. Nom: `JavaFX` (exactement comme ça)
6. Cliquer: **Add External JARs...**
7. Naviguer vers: `javafx-sdk-25.0.2/lib/`
8. Sélectionner **TOUS** les fichiers .jar
9. Cliquer: **Apply and Close**

### ÉTAPE B: Configurer MySQL Connector

1. Dans Eclipse: **Window → Preferences**
2. **Java → Build Path → User Libraries**
3. Cliquer: **New**
4. Nom: `MySQL`
5. Cliquer: **Add External JARs...**
6. Sélectionner: `mysql-connector-java-8.0.xx.jar`
7. Cliquer: **Apply and Close**

### ÉTAPE C: Créer la Base de Données

1. Ouvrir MySQL Workbench ou ligne de commande MySQL
2. Se connecter avec vos identifiants
3. Exécuter le script `database/smartfight_schema.sql` qui est dans le projet
   
   **OU** copier-coller ce code :

```sql
CREATE DATABASE smartfight;
USE smartfight;
-- Puis exécuter tout le contenu du fichier smartfight_schema.sql
```

### ÉTAPE D: Configurer la Connexion à la BD

1. Ouvrir le fichier: `src/com/smartfight/util/DatabaseConnection.java`
2. Modifier ces lignes (lignes 11-13) :

```java
private static final String URL = "jdbc:mysql://localhost:3306/smartfight";
private static final String USER = "root";           // ← Votre utilisateur MySQL
private static final String PASSWORD = "votre_mdp";   // ← Votre mot de passe MySQL
```

### ÉTAPE E: Importer le Projet dans Eclipse

1. Dans Eclipse: **File → Import**
2. Sélectionner: **General → Existing Projects into Workspace**
3. **Next**
4. **Select root directory**: Parcourir vers le dossier `smartfight-project`
5. Cocher le projet qui apparaît
6. **Finish**

### ÉTAPE F: Configurer les VM Arguments

1. Clic droit sur le projet `SmartFight`
2. **Run As → Run Configurations...**
3. Clic droit sur **Java Application** → **New Configuration**
4. Onglet **Main**:
   - Project: `SmartFight`
   - Main class: `com.smartfight.MainApp` (cliquer sur Search...)
5. Onglet **Arguments**
6. Dans **VM arguments**, coller:

```
--module-path "C:/chemin/vers/javafx-sdk-25.0.2/lib" --add-modules javafx.controls,javafx.fxml
```

⚠️ **IMPORTANT**: Remplacer `C:/chemin/vers/` par le vrai chemin vers votre JavaFX SDK !

Exemples:
- Windows: `C:/Users/VotreNom/Downloads/javafx-sdk-25.0.2/lib`
- Mac: `/Users/VotreNom/Downloads/javafx-sdk-25.0.2/lib`
- Linux: `/home/votrenom/Downloads/javafx-sdk-25.0.2/lib`

7. Cliquer: **Apply** puis **Run**

---

## 3️⃣ Lancer l'Application

**Méthode 1: Via Run Configuration (recommandé)**
1. Clic droit sur le projet
2. **Run As → Run Configurations...**
3. Sélectionner la configuration créée à l'étape F
4. Cliquer **Run**

**Méthode 2: Directement**
1. Ouvrir `src/com/smartfight/MainApp.java`
2. Clic droit dans l'éditeur
3. **Run As → Java Application**

Si vous voyez l'interface graphique, **FÉLICITATIONS** ! 🎉

---

## 4️⃣ Vérifications de Démarrage

Au démarrage, l'application affiche dans la console :

```
✓ Connexion à la base de données établie
✓ Application SmartFight démarrée avec succès
```

Si vous voyez ces messages, tout fonctionne ! ✅

---

## ❌ Problèmes Courants

### Problème 1: "Error: JavaFX runtime components are missing"

**Solution**:
- Vérifier que les VM arguments sont corrects
- Vérifier le chemin vers JavaFX SDK
- Vérifier que `--add-modules javafx.controls,javafx.fxml` est présent

### Problème 2: "SQLException: Access denied for user..."

**Solution**:
- Vérifier l'utilisateur et mot de passe dans `DatabaseConnection.java`
- Vérifier que MySQL server est bien démarré
- Tester la connexion avec MySQL Workbench

### Problème 3: "ClassNotFoundException: com.mysql.cj.jdbc.Driver"

**Solution**:
- Vérifier que MySQL Connector JAR est bien ajouté aux User Libraries
- Vérifier que la bibliothèque "MySQL" est référencée dans le .classpath

### Problème 4: Tables vides / "Aucun combattant trouvé"

**Solution**:
- Exécuter le script `smartfight_schema.sql` qui contient des données de test
- Vérifier que la base de données `smartfight` existe
- Vérifier la connexion à la base

### Problème 5: CSS ne se charge pas

**Solution**:
- Vérifier que le dossier `resources` est bien dans le Build Path
- Clic droit sur projet → **Properties → Java Build Path → Source**
- Ajouter `resources` comme source folder si nécessaire

---

## 📊 Tester l'Application

### Test 1: Dashboard
- Vous devriez voir des statistiques
- Nombre de combattants, classements, etc.

### Test 2: Combattants
- Cliquer sur "🥋 Combattants" dans le menu
- Vous devriez voir une liste de 15+ combattants
- Tester la recherche

### Test 3: Matchmaking
- Cliquer sur "⚔️ Matchmaking"
- Nombre de matchs: 10
- Cliquer "🎲 Générer les matchs"
- Des matchs avec scores de qualité s'affichent

### Test 4: Classements
- Cliquer sur "🏆 Classements"
- Cliquer "♻️ Recalculer"
- Confirmer
- Les classements s'affichent avec rangs

---

## 📱 Structure du Projet

```
smartfight-project/
├── src/                     ← Code source Java
│   └── com/smartfight/
│       ├── MainApp.java     ← Point d'entrée
│       ├── model/           ← Modèles de données
│       ├── dao/             ← Accès base de données
│       ├── service/         ← Logique métier
│       ├── controller/      ← Contrôleurs
│       ├── view/            ← Interfaces JavaFX
│       ├── algorithm/       ← Algorithmes AI
│       └── util/            ← Utilitaires
├── resources/               ← Ressources (CSS, images)
├── database/                ← Scripts SQL
├── README.md                ← Documentation complète
└── .classpath, .project     ← Config Eclipse
```

---

## 🎓 Pour Aller Plus Loin

### Ajouter des Combattants

```sql
INSERT INTO fighter (name, surname, date_of_birth, nationality, 
                     height_cm, weight_kg, wins, losses, draws, 
                     stance, discipline_id, weight_class_id) 
VALUES ('Nouveau', 'Combattant', '1990-01-01', 'France', 
        180, 77, 10, 2, 0, 'Orthodox', 1, 5);
```

### Modifier les Algorithmes

- **Matchmaking**: `src/com/smartfight/algorithm/MatchmakingAlgorithm.java`
  - Lignes 19-22: Ajuster les poids des critères
  
- **Ranking**: `src/com/smartfight/algorithm/RankingAlgorithm.java`
  - Lignes 22-26: Ajuster les bonus et pénalités

### Personnaliser l'Interface

- **CSS**: `resources/css/style.css`
- **Couleurs**: Modifier les codes hexadécimaux (#3498db, etc.)
- **Tailles**: Modifier les valeurs de font-size, padding, etc.

---

## 📞 Support

Si vous rencontrez des problèmes :

1. Vérifier la console Eclipse pour les messages d'erreur
2. Vérifier que tous les prérequis sont installés
3. Vérifier les versions (Java 11+, JavaFX 17+)
4. Consulter le README.md complet pour plus de détails

---

## ✅ Checklist Finale

Avant de soumettre votre projet :

- [ ] L'application démarre sans erreur
- [ ] La connexion à la base de données fonctionne
- [ ] Les 4 onglets (Dashboard, Combattants, Matchmaking, Rankings) fonctionnent
- [ ] Le matchmaking génère des combats
- [ ] Les classements se calculent
- [ ] L'interface est responsive
- [ ] Le code est bien commenté
- [ ] Le README est à jour

---

**Bon courage pour votre projet ! 🚀🥊**

*Niveau Licence/Master - Système de Matchmaking IA*
