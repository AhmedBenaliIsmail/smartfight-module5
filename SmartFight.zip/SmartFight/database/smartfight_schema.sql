-- ========================================
-- Script SQL pour SmartFight Database
-- ========================================

-- Créer la base de données
CREATE DATABASE IF NOT EXISTS smartfight CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smartfight;

-- Table: discipline
CREATE TABLE IF NOT EXISTS discipline (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: weight_class
CREATE TABLE IF NOT EXISTS weight_class (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    min_weight_kg DECIMAL(5,2) NOT NULL,
    max_weight_kg DECIMAL(5,2) NOT NULL,
    discipline_id INT,
    FOREIGN KEY (discipline_id) REFERENCES discipline(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: user
CREATE TABLE IF NOT EXISTS user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: user_role
CREATE TABLE IF NOT EXISTS user_role (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    role VARCHAR(50) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: fighter
CREATE TABLE IF NOT EXISTS fighter (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    surname VARCHAR(100) NOT NULL,
    date_of_birth DATE,
    nationality VARCHAR(100),
    height_cm INT,
    weight_kg DECIMAL(5,2),
    wins INT DEFAULT 0,
    losses INT DEFAULT 0,
    draws INT DEFAULT 0,
    stance VARCHAR(50),
    discipline_id INT,
    weight_class_id INT,
    profile_image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (discipline_id) REFERENCES discipline(id),
    FOREIGN KEY (weight_class_id) REFERENCES weight_class(id),
    INDEX idx_weight_class (weight_class_id),
    INDEX idx_discipline (discipline_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: coach
CREATE TABLE IF NOT EXISTS coach (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    name VARCHAR(100) NOT NULL,
    surname VARCHAR(100) NOT NULL,
    specialization VARCHAR(100),
    years_experience INT,
    FOREIGN KEY (user_id) REFERENCES user(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: fighter_coach
CREATE TABLE IF NOT EXISTS fighter_coach (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fighter_id INT NOT NULL,
    coach_id INT NOT NULL,
    start_date DATE,
    end_date DATE,
    FOREIGN KEY (fighter_id) REFERENCES fighter(id) ON DELETE CASCADE,
    FOREIGN KEY (coach_id) REFERENCES coach(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: venue
CREATE TABLE IF NOT EXISTS venue (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    address VARCHAR(255),
    city VARCHAR(100),
    country VARCHAR(100),
    capacity INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: event
CREATE TABLE IF NOT EXISTS event (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    event_date DATE NOT NULL,
    venue_id INT,
    status VARCHAR(50) DEFAULT 'SCHEDULED',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (venue_id) REFERENCES venue(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: event_schedule
CREATE TABLE IF NOT EXISTS event_schedule (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    fight_order INT,
    scheduled_time TIME,
    status VARCHAR(50),
    FOREIGN KEY (event_id) REFERENCES event(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: match_proposal
CREATE TABLE IF NOT EXISTS match_proposal (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fighter1_id INT NOT NULL,
    fighter2_id INT NOT NULL,
    event_id INT,
    match_score DECIMAL(5,2),
    status VARCHAR(50) DEFAULT 'PROPOSED',
    proposed_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    match_type VARCHAR(50),
    weight_class_id INT,
    reasoning TEXT,
    FOREIGN KEY (fighter1_id) REFERENCES fighter(id) ON DELETE CASCADE,
    FOREIGN KEY (fighter2_id) REFERENCES fighter(id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES event(id),
    FOREIGN KEY (weight_class_id) REFERENCES weight_class(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: matchmaking_rule
CREATE TABLE IF NOT EXISTS matchmaking_rule (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(100) NOT NULL,
    rule_type VARCHAR(50),
    parameter_name VARCHAR(100),
    parameter_value VARCHAR(255),
    weight DECIMAL(3,2),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: fight_result
CREATE TABLE IF NOT EXISTS fight_result (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    fighter1_id INT NOT NULL,
    fighter2_id INT NOT NULL,
    winner_id INT,
    result_type VARCHAR(50),
    round INT,
    time_seconds INT,
    fight_date DATE,
    notes TEXT,
    FOREIGN KEY (event_id) REFERENCES event(id),
    FOREIGN KEY (fighter1_id) REFERENCES fighter(id),
    FOREIGN KEY (fighter2_id) REFERENCES fighter(id),
    FOREIGN KEY (winner_id) REFERENCES fighter(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: fight_statistic
CREATE TABLE IF NOT EXISTS fight_statistic (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fight_result_id INT NOT NULL,
    fighter_id INT NOT NULL,
    strikes_landed INT DEFAULT 0,
    strikes_attempted INT DEFAULT 0,
    takedowns_landed INT DEFAULT 0,
    takedowns_attempted INT DEFAULT 0,
    submission_attempts INT DEFAULT 0,
    knockdowns INT DEFAULT 0,
    control_time_seconds INT DEFAULT 0,
    significant_strikes INT DEFAULT 0,
    FOREIGN KEY (fight_result_id) REFERENCES fight_result(id) ON DELETE CASCADE,
    FOREIGN KEY (fighter_id) REFERENCES fighter(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: judge_score
CREATE TABLE IF NOT EXISTS judge_score (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fight_result_id INT NOT NULL,
    judge_name VARCHAR(100),
    round INT,
    fighter1_score INT,
    fighter2_score INT,
    FOREIGN KEY (fight_result_id) REFERENCES fight_result(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: ranking
CREATE TABLE IF NOT EXISTS ranking (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fighter_id INT NOT NULL,
    weight_class_id INT NOT NULL,
    rank INT NOT NULL,
    score DECIMAL(10,2) DEFAULT 1000.00,
    previous_rank INT,
    last_updated DATE,
    FOREIGN KEY (fighter_id) REFERENCES fighter(id) ON DELETE CASCADE,
    FOREIGN KEY (weight_class_id) REFERENCES weight_class(id),
    UNIQUE KEY unique_fighter_weight (fighter_id, weight_class_id),
    INDEX idx_rank (weight_class_id, rank)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: performance_score
CREATE TABLE IF NOT EXISTS performance_score (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fighter_id INT NOT NULL,
    fight_result_id INT NOT NULL,
    overall_score DECIMAL(5,2),
    striking_score DECIMAL(5,2),
    grappling_score DECIMAL(5,2),
    endurance_score DECIMAL(5,2),
    technique_score DECIMAL(5,2),
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (fighter_id) REFERENCES fighter(id),
    FOREIGN KEY (fight_result_id) REFERENCES fight_result(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: event_fighter
CREATE TABLE IF NOT EXISTS event_fighter (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    fighter_id INT NOT NULL,
    weight_in_kg DECIMAL(5,2),
    status VARCHAR(50),
    FOREIGN KEY (event_id) REFERENCES event(id) ON DELETE CASCADE,
    FOREIGN KEY (fighter_id) REFERENCES fighter(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: fan_profile
CREATE TABLE IF NOT EXISTS fan_profile (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    favorite_fighter_id INT,
    favorite_discipline_id INT,
    FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
    FOREIGN KEY (favorite_fighter_id) REFERENCES fighter(id),
    FOREIGN KEY (favorite_discipline_id) REFERENCES discipline(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: admin
CREATE TABLE IF NOT EXISTS admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    access_level INT DEFAULT 1,
    FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========================================
-- INSERTION DES DONNÉES DE TEST
-- ========================================

-- Insérer des disciplines
INSERT INTO discipline (name, description) VALUES
('MMA', 'Mixed Martial Arts'),
('Boxing', 'Boxe traditionnelle'),
('Muay Thai', 'Boxe thaïlandaise'),
('Kickboxing', 'Kickboxing'),
('Jiu-Jitsu', 'Brazilian Jiu-Jitsu');

-- Insérer des catégories de poids (MMA)
INSERT INTO weight_class (name, min_weight_kg, max_weight_kg, discipline_id) VALUES
('Poids Mouche', 0, 57, 1),
('Poids Coq', 57.1, 61.2, 1),
('Poids Plume', 61.3, 65.8, 1),
('Poids Léger', 65.9, 70.3, 1),
('Poids Welter', 70.4, 77.1, 1),
('Poids Moyen', 77.2, 83.9, 1),
('Poids Mi-lourd', 84.0, 93.0, 1),
('Poids Lourd', 93.1, 120.0, 1);

-- Insérer des combattants de test
INSERT INTO fighter (name, surname, date_of_birth, nationality, height_cm, weight_kg, wins, losses, draws, stance, discipline_id, weight_class_id) VALUES
-- Poids Léger (70kg)
('McGregor', 'Conor', '1988-07-14', 'Ireland', 175, 70.0, 22, 6, 0, 'Southpaw', 1, 4),
('Nurmagomedov', 'Khabib', '1988-09-20', 'Russia', 178, 70.0, 29, 0, 0, 'Orthodox', 1, 4),
('Poirier', 'Dustin', '1989-01-19', 'USA', 175, 70.0, 28, 7, 0, 'Orthodox', 1, 4),
('Oliveira', 'Charles', '1989-10-17', 'Brazil', 178, 70.0, 33, 9, 0, 'Orthodox', 1, 4),
('Chandler', 'Michael', '1986-04-24', 'USA', 173, 70.0, 23, 8, 0, 'Orthodox', 1, 4),

-- Poids Welter (77kg)
('St-Pierre', 'Georges', '1981-05-19', 'Canada', 178, 77.0, 26, 2, 0, 'Southpaw', 1, 5),
('Usman', 'Kamaru', '1987-05-11', 'Nigeria', 183, 77.0, 20, 3, 0, 'Orthodox', 1, 5),
('Edwards', 'Leon', '1991-08-25', 'UK', 183, 77.0, 21, 3, 0, 'Orthodox', 1, 5),
('Covington', 'Colby', '1988-02-22', 'USA', 180, 77.0, 17, 3, 0, 'Orthodox', 1, 5),

-- Poids Moyen (84kg)
('Silva', 'Anderson', '1975-04-14', 'Brazil', 188, 84.0, 34, 11, 0, 'Orthodox', 1, 6),
('Adesanya', 'Israel', '1989-07-22', 'Nigeria', 193, 84.0, 24, 2, 0, 'Southpaw', 1, 6),
('Whittaker', 'Robert', '1990-12-20', 'Australia', 183, 84.0, 25, 6, 0, 'Orthodox', 1, 6),
('Pereira', 'Alex', '1987-07-07', 'Brazil', 193, 84.0, 8, 2, 0, 'Orthodox', 1, 6),

-- Poids Lourd (100kg+)
('Ngannou', 'Francis', '1986-09-05', 'Cameroon', 193, 115.0, 17, 3, 0, 'Orthodox', 1, 8),
('Jones', 'Jon', '1987-07-19', 'USA', 193, 112.0, 27, 1, 0, 'Orthodox', 1, 8),
('Miocic', 'Stipe', '1982-08-19', 'USA', 193, 110.0, 20, 4, 0, 'Orthodox', 1, 8);

-- Insérer quelques venues
INSERT INTO venue (name, address, city, country, capacity) VALUES
('T-Mobile Arena', '3780 Las Vegas Blvd', 'Las Vegas', 'USA', 20000),
('Madison Square Garden', '4 Pennsylvania Plaza', 'New York', 'USA', 20789),
('O2 Arena', 'Peninsula Square', 'London', 'UK', 20000);

-- ========================================
-- Fin du script
-- ========================================

-- Afficher un message de succès
SELECT 'Database smartfight created and populated successfully!' as Status;
