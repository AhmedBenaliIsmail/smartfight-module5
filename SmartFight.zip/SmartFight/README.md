# 🥊 SmartFight - AI Matchmaking & Rankings System

## 📋 Description du Projet

SmartFight est une plateforme intelligente de gestion d'événements de sports de combat avec un système avancé de matchmaking automatique et de classement dynamique. Le projet utilise des algorithmes d'intelligence artificielle pour créer des combats équilibrés et maintenir des classements justes basés sur les performances.

## 🎯 Fonctionnalités Principales

### 1. **Matchmaking Intelligent**
- Génération automatique de combats équilibrés
- Algorithme basé sur plusieurs critères :
  - Catégorie de poids (obligatoire)
  - Expérience (nombre de combats)
  - Taux de victoire
  - Classement actuel
  - Séries de victoires/défaites
- Score de qualité du match (0-100)
- Explications détaillées pour chaque proposition

### 2. **Système de Classement Dynamique**
- Algorithme ELO modifié pour les sports de combat
- Prise en compte de :
  - Performances récentes
  - Qualité des adversaires
  - Séries de victoires
  - Activité du combattant
- Mise à jour automatique après chaque combat
- Historique des rangs

### 3. **Gestion des Combattants**
- Base de données complète des combattants
- Profils détaillés (statistiques, records, etc.)
- Recherche et filtrage avancés
- Catégorisation par poids et discipline

### 4. **Visualisations Graphiques**
- Dashboard avec statistiques en temps réel
- Graphiques de classement (Top 10)
- Interface intuitive et moderne
- Tableaux interactifs avec tri et filtrage

## 🏗️ Architecture du Projet

### Pattern MVC (Model-View-Controller)

```
smartfight-project/
│
├── src/com/smartfight/
│   ├── model/              # Modèles de données
│   │   ├── Fighter.java
│   │   ├── MatchProposal.java
│   │   ├── Ranking.java
│   │   ├── FightStatistic.java
│   │   └── WeightClass.java
│   │
│   ├── dao/                # Data Access Objects
│   │   ├── FighterDAO.java
│   │   ├── RankingDAO.java
│   │   └── WeightClassDAO.java
│   │
│   ├── service/            # Logique métier
│   │   └── SmartFightService.java
│   │
│   ├── controller/         # Contrôleurs
│   │   └── MainController.java
│   │
│   ├── algorithm/          # Algorithmes AI
│   │   ├── MatchmakingAlgorithm.java
│   │   └── RankingAlgorithm.java
│   │
│   ├── view/               # Vues JavaFX
│   │   ├── MainView.java
│   │   └── scenes/
│   │       ├── DashboardScene.java
│   │       ├── FightersScene.java
│   │       ├── MatchmakingScene.java
│   │       └── RankingsScene.java
│   │
│   ├── util/               # Utilitaires
│   │   └── DatabaseConnection.java
│   │
│   └── MainApp.java        # Point d'entrée
│
├── resources/
│   ├── css/
│   │   └── style.css       # Feuilles de style
│   ├── fxml/               # Fichiers FXML (optionnel)
│   └── images/             # Images et icônes
│
├── lib/                    # Bibliothèques externes
├── .classpath              # Configuration Eclipse
├── .project                # Projet Eclipse
└── pom.xml                 # Configuration Maven
```

## 📊 Base de Données

### Tables Principales

1. **fighter** - Informations des combattants
   - id, name, surname, date_of_birth, nationality
   - height_cm, weight_kg
   - wins, losses, draws
   - stance, discipline_id, weight_class_id

2. **ranking** - Classements des combattants
   - id, fighter_id, weight_class_id
   - rank, score, previous_rank
   - last_updated

3. **match_proposal** - Propositions de matchs
   - id, fighter1_id, fighter2_id
   - match_score, status, proposed_date
   - match_type, reasoning

4. **weight_class** - Catégories de poids
   - id, name, min_weight_kg, max_weight_kg
   - discipline_id

5. **fight_statistic** - Statistiques détaillées
   - strikes_landed, takedowns, submissions, etc.

## 🚀 Installation et Configuration

### Prérequis

1. **Java Development Kit (JDK) 11 ou supérieur**
   - Télécharger depuis : https://www.oracle.com/java/technologies/downloads/

2. **Eclipse IDE**
   - Télécharger depuis : https://www.eclipse.org/downloads/

3. **MySQL Server**
   - Télécharger depuis : https://dev.mysql.com/downloads/

4. **JavaFX SDK 17+**
   - Vous avez déjà téléchargé javafx-sdk-25.0.2

### Étapes d'Installation

#### 1. Configuration de JavaFX dans Eclipse

1. Ouvrir Eclipse
2. Aller dans **Window → Preferences**
3. **Java → Build Path → User Libraries**
4. Cliquer sur **New** et nommer "JavaFX"
5. Sélectionner la bibliothèque JavaFX et cliquer sur **Add External JARs**
6. Naviguer vers `javafx-sdk-25.0.2/lib/` et sélectionner tous les fichiers .jar
7. Cliquer sur **Apply and Close**

#### 2. Configuration MySQL Connector

1. Télécharger MySQL Connector/J depuis :
   https://dev.mysql.com/downloads/connector/j/
2. Dans Eclipse : **Window → Preferences → Java → Build Path → User Libraries**
3. Cliquer sur **New** et nommer "MySQL"
4. **Add External JARs** → Sélectionner `mysql-connector-java-x.x.xx.jar`

#### 3. Création de la Base de Données

```sql
-- Créer la base de données
CREATE DATABASE smartfight;
USE smartfight;

-- Créer les tables (utiliser votre schéma existant)
-- Exemple de quelques combattants pour tester

INSERT INTO fighter (name, surname, date_of_birth, nationality, height_cm, weight_kg, 
                     wins, losses, draws, stance, discipline_id, weight_class_id) 
VALUES 
('McGregor', 'Conor', '1988-07-14', 'Ireland', 175, 70, 22, 6, 0, 'Southpaw', 1, 3),
('Nurmagomedov', 'Khabib', '1988-09-20', 'Russia', 178, 70, 29, 0, 0, 'Orthodox', 1, 3),
('St-Pierre', 'Georges', '1981-05-19', 'Canada', 178, 77, 26, 2, 0, 'Southpaw', 1, 4),
('Silva', 'Anderson', '1975-04-14', 'Brazil', 188, 84, 34, 11, 0, 'Orthodox', 1, 5);
```

#### 4. Configuration de la Connexion

Ouvrir `src/com/smartfight/util/DatabaseConnection.java` et modifier :

```java
private static final String URL = "jdbc:mysql://localhost:3306/smartfight";
private static final String USER = "root";        // Votre utilisateur MySQL
private static final String PASSWORD = "";        // Votre mot de passe MySQL
```

#### 5. Importer le Projet dans Eclipse

1. **File → Import → General → Existing Projects into Workspace**
2. Sélectionner le dossier `smartfight-project`
3. Cliquer sur **Finish**

#### 6. Configurer VM Arguments

1. Clic droit sur le projet → **Run As → Run Configurations**
2. Sélectionner **Java Application → MainApp**
3. Onglet **Arguments**
4. Dans **VM arguments**, ajouter :

```
--module-path "CHEMIN_VERS/javafx-sdk-25.0.2/lib" --add-modules javafx.controls,javafx.fxml
```

Remplacer `CHEMIN_VERS` par le chemin réel vers votre JavaFX SDK.

#### 7. Lancer l'Application

1. Clic droit sur `MainApp.java`
2. **Run As → Java Application**

## 📖 Guide d'Utilisation

### Dashboard
- Vue d'ensemble avec statistiques
- Nombre total de combattants, classements, victoires
- Informations sur le système

### Combattants
- Tableau de tous les combattants
- Recherche par nom
- Affichage des records et statistiques
- Filtrage par catégories

### Matchmaking
1. Choisir le nombre de matchs à générer
2. Cliquer sur "Générer les matchs"
3. Voir la liste des propositions avec scores de qualité
4. Sélectionner un match pour voir les détails complets
5. Codes couleurs :
   - 🟢 Vert (85+) : Excellent match
   - 🟡 Orange (70-84) : Bon match
   - 🔴 Rouge (<70) : Match acceptable

### Classements
- Voir les classements par catégorie
- Filtrer par catégorie de poids
- Recalculer les classements
- Graphique Top 10
- Tendances (↑ montée, ↓ descente, → stable)

## 🧮 Algorithmes

### Algorithme de Matchmaking

Le score de qualité d'un match est calculé selon :

```
Score Total = (Score Expérience × 0.25) + 
              (Score Taux de Victoire × 0.30) + 
              (Score Classement × 0.25) + 
              (Score Série × 0.20)
```

**Critères :**
- Différence d'expérience < 8 combats
- Différence de taux de victoire < 25%
- Classements proches
- Séries de victoires similaires

### Algorithme de Classement (ELO Modifié)

```
Score = Score Base (1000) +
        Bonus Victoires (50 × victoires) -
        Pénalité Défaites (30 × défaites) +
        Bonus Série +
        Bonus Qualité Adversaires +
        Bonus Activité +
        Bonus Dominance
```

**Mise à jour après combat :**
```
Nouveau Score = Score Actuel + K × (Résultat Réel - Résultat Attendu)
```
- K = 32 (facteur de variation)
- K × 1.5 pour victoire dominante

## 🎨 Interface Utilisateur

- **Design moderne** avec Material Design
- **Responsive** et adaptative
- **Codes couleurs** pour faciliter la lecture
- **Animations** fluides
- **Feedback visuel** sur les actions

### Palette de Couleurs

- Bleu (#3498db) : Actions principales
- Vert (#2ecc71) : Succès/Validation
- Rouge (#e74c3c) : Danger/Suppression
- Orange (#f39c12) : Avertissement
- Gris foncé (#2c3e50) : Navigation

## 🔧 Technologies Utilisées

- **Java 11+** - Langage de programmation
- **JavaFX 17+** - Interface graphique
- **MySQL 8.0** - Base de données
- **JDBC** - Connexion base de données
- **Eclipse** - Environnement de développement

## 📚 Structure des Classes

### Modèles (Model)
- Représentent les entités métier
- POJOs (Plain Old Java Objects)
- Getters/Setters et méthodes utilitaires

### DAO (Data Access Object)
- Gestion de la persistance
- Opérations CRUD (Create, Read, Update, Delete)
- Isolation de la logique d'accès aux données

### Services
- Logique métier
- Orchestration des DAO et algorithmes
- Point d'entrée pour les contrôleurs

### Contrôleurs
- Gestion des interactions utilisateur
- Lien entre la vue et le modèle
- ObservableLists pour JavaFX

### Vues (View)
- Interfaces graphiques JavaFX
- Composants réutilisables
- Liaison avec les contrôleurs

## 🐛 Dépannage

### Problème : Application ne démarre pas
- Vérifier que JavaFX est bien configuré dans les VM arguments
- Vérifier la version de Java (JDK 11+)

### Problème : Erreur de connexion MySQL
- Vérifier que MySQL server est démarré
- Vérifier les identifiants dans `DatabaseConnection.java`
- Vérifier que la base de données `smartfight` existe

### Problème : Tables vides
- Insérer des données de test dans la base
- Vérifier que les requêtes SQL s'exécutent sans erreur

### Problème : JavaFX CSS ne se charge pas
- Vérifier que le chemin dans MainApp.java est correct
- Vérifier que `style.css` est dans `resources/css/`

## 📈 Améliorations Futures

1. **Gestion des événements**
   - Planification des combats
   - Calendrier des événements
   - Gestion des venues

2. **Statistiques avancées**
   - Graphiques d'évolution
   - Analyse prédictive
   - Rapports détaillés

3. **Module administrateur**
   - Gestion des utilisateurs
   - Permissions et rôles
   - Logs d'activité

4. **Export/Import**
   - Export PDF des classements
   - Export Excel des statistiques
   - Import de combattants

5. **API REST**
   - Intégration avec d'autres systèmes
   - Application mobile companion

## 👥 Auteur

Projet étudiant - Niveau Licence/Master Informatique

## 📝 Licence

Ce projet est à usage éducatif.

## 🙏 Remerciements

- Communauté JavaFX
- Documentation Oracle Java
- Ressources pédagogiques en algorithmes

---

**Bon développement ! 🚀**
