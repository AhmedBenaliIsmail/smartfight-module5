# 📊 Documentation Technique - Algorithmes SmartFight

## Table des Matières
1. [Algorithme de Matchmaking](#algorithme-de-matchmaking)
2. [Algorithme de Ranking](#algorithme-de-ranking)
3. [Architecture MVC](#architecture-mvc)
4. [Schéma de Base de Données](#schéma-de-base-de-données)

---

## 1. Algorithme de Matchmaking

### 🎯 Objectif
Créer des combats équilibrés et compétitifs en analysant plusieurs critères de compatibilité entre combattants.

### 📐 Formule Mathématique

Le **Score de Qualité du Match** est calculé selon :

```
Score_Total = (Score_Expérience × 0.25) + 
              (Score_TauxVictoire × 0.30) + 
              (Score_Classement × 0.25) + 
              (Score_Série × 0.20)
```

**Échelle** : 0 à 100 (100 = match parfait)

### 🔢 Détail des Calculs

#### 1. Score d'Expérience (Poids: 25%)

```java
int difference = |expérience_combattant1 - expérience_combattant2|

if (difference > 8) {
    score = 0  // Trop de différence
} else {
    score = 100 × (1 - difference / 8)
}
```

**Exemples:**
- Différence de 0 combats → Score = 100
- Différence de 2 combats → Score = 75
- Différence de 4 combats → Score = 50
- Différence de 8 combats → Score = 0

**Raison**: Les combattants d'expérience similaire offrent des combats plus équilibrés.

#### 2. Score de Taux de Victoire (Poids: 30%)

```java
double difference = |tauxVictoire1 - tauxVictoire2|

if (difference > 25%) {
    score = 0
} else {
    score = 100 × (1 - difference / 25)
}
```

**Exemples:**
- Différence de 0% → Score = 100
- Différence de 10% → Score = 60
- Différence de 20% → Score = 20
- Différence de 25%+ → Score = 0

**Raison**: C'est le critère le plus important car il reflète la performance globale.

#### 3. Score de Classement (Poids: 25%)

```java
if (classement1 == 0 || classement2 == 0) {
    score = 50  // Score neutre si pas de classement
} else {
    double difference = |score1 - score2|
    double maxScore = max(score1, score2)
    score = 100 × (1 - min(1, difference / maxScore))
}
```

**Exemples:**
- Classés #1 vs #2 → Score très élevé
- Classés #1 vs #10 → Score faible
- Non classés → Score = 50

#### 4. Score de Série (Poids: 20%)

```java
boolean serie1 = (victoires > 0 && tauxVictoire > 60%)
boolean serie2 = (victoires > 0 && tauxVictoire > 60%)

if (serie1 == serie2) {
    score = 100  // Les deux en forme ou pas
} else {
    score = 60   // Un en forme, l'autre pas
}
```

**Raison**: Matcher des combattants dans des dynamiques similaires.

### 🎪 Catégorisation des Matchs

Selon le score final :

| Score | Qualité | Type de Combat Suggéré |
|-------|---------|------------------------|
| 90-100 | Excellent | Main Event / Title Fight |
| 75-89 | Très bon | Co-Main Event |
| 60-74 | Bon | Featured Fight |
| 50-59 | Acceptable | Undercard |
| <50 | Rejeté | Non proposé |

### 🔍 Exemple Concret

**Combattant A**: Conor McGregor
- Expérience: 28 combats
- Taux de victoire: 78.6% (22-6-0)
- Score de ranking: 1450
- En série: Oui

**Combattant B**: Dustin Poirier
- Expérience: 35 combats
- Taux de victoire: 80.0% (28-7-0)
- Score de ranking: 1480
- En série: Oui

**Calcul:**
```
Score_Expérience = 100 × (1 - 7/8) = 12.5 → × 0.25 = 3.125
Score_TauxVictoire = 100 × (1 - 1.4/25) = 94.4 → × 0.30 = 28.32
Score_Classement = 100 × (1 - 30/1480) = 98.0 → × 0.25 = 24.5
Score_Série = 100 → × 0.20 = 20.0

Score_Total = 3.125 + 28.32 + 24.5 + 20.0 = 75.945 ≈ 76/100
```

**Résultat**: Très bon match → Co-Main Event ✅

---

## 2. Algorithme de Ranking

### 🎯 Objectif
Maintenir un classement dynamique et juste basé sur les performances, inspiré du système ELO.

### 📐 Formule de Base

```
Score_Combattant = Score_Base (1000) +
                   Bonus_Victoires +
                   Bonus_Série +
                   Bonus_Qualité_Adversaires +
                   Bonus_Activité +
                   Bonus_Dominance -
                   Pénalité_Défaites
```

### 🔢 Détail des Calculs

#### Constantes du Système

```java
BASE_SCORE = 1000.0          // Score de départ
K_FACTOR = 32.0              // Facteur de variation (ELO)
WIN_BONUS = 50.0             // Bonus par victoire
LOSS_PENALTY = 30.0          // Pénalité par défaite
STREAK_MULTIPLIER = 1.2      // Multiplicateur de série
DOMINANCE_BONUS = 20.0       // Bonus performance dominante
```

#### 1. Score Victoires/Défaites

```java
score_victoires = nombre_victoires × 50
score_défaites = nombre_défaites × 30

score_WL = score_victoires - score_défaites
```

**Exemple:**
- 22 victoires, 6 défaites
- Score = (22 × 50) - (6 × 30) = 1100 - 180 = 920

#### 2. Bonus de Série

```java
if (tauxVictoire >= 75% && victoires >= 3) {
    bonus = WIN_BONUS × STREAK_MULTIPLIER × (victoires / 3)
} else if (tauxVictoire >= 60% && victoires >= 2) {
    bonus = WIN_BONUS × (victoires / 4)
} else {
    bonus = 0
}
```

**Exemple:**
- 22 victoires, taux 78.6%
- Bonus = 50 × 1.2 × (22/3) = 60 × 7.33 = 440

#### 3. Bonus d'Activité

```java
if (total_combats >= 20) {
    bonus = 100
} else if (total_combats >= 10) {
    bonus = 50
} else if (total_combats >= 5) {
    bonus = 25
} else {
    bonus = 0
}
```

#### 4. Bonus de Dominance

```java
if (tauxVictoire >= 90%) {
    bonus = DOMINANCE_BONUS × 3
} else if (tauxVictoire >= 80%) {
    bonus = DOMINANCE_BONUS × 2
} else if (tauxVictoire >= 70%) {
    bonus = DOMINANCE_BONUS
} else {
    bonus = 0
}
```

#### 5. Mise à Jour Après Combat (ELO)

Quand deux combattants s'affrontent :

```java
// Probabilité de victoire attendue (formule ELO)
P_victoire = 1 / (1 + 10^((Score_Adversaire - Score_Combattant)/400))

// Résultat réel
R = 1 si victoire, 0 si défaite

// Nouveau score
Nouveau_Score = Score_Actuel + K × (R - P_victoire)

// Si victoire dominante (KO, soumission)
K = K × 1.5
```

### 📊 Exemple de Classement

| Rang | Combattant | Score | Calcul |
|------|------------|-------|--------|
| 1 | Khabib (29-0) | 2450 | Base + (29×50) + Série + Dominance + Activité |
| 2 | GSP (26-2) | 2180 | Base + (26×50) - (2×30) + Série + Activité |
| 3 | McGregor (22-6) | 1890 | Base + (22×50) - (6×30) + Activité |
| 4 | Poirier (28-7) | 1850 | Base + (28×50) - (7×30) + Activité |

### 🔄 Exemple de Mise à Jour

**Avant combat:**
- McGregor: Score = 1890
- Poirier: Score = 1850

**Probabilités:**
```
P_McGregor = 1 / (1 + 10^((1850-1890)/400))
           = 1 / (1 + 10^(-0.1))
           = 1 / (1 + 0.794)
           = 0.557 (55.7% de chances de gagner)

P_Poirier = 1 - 0.557 = 0.443 (44.3%)
```

**Si McGregor gagne:**
```
Nouveau_Score_McGregor = 1890 + 32 × (1 - 0.557)
                       = 1890 + 32 × 0.443
                       = 1890 + 14.2
                       = 1904.2

Nouveau_Score_Poirier = 1850 + 32 × (0 - 0.443)
                      = 1850 - 14.2
                      = 1835.8
```

**Si victoire dominante (KO):**
```
K = 32 × 1.5 = 48

Nouveau_Score_McGregor = 1890 + 48 × 0.443 = 1911.3
```

---

## 3. Architecture MVC

### 📦 Couches de l'Application

```
┌─────────────────────────────────────────┐
│           VIEW (Interface)               │
│  - MainView.java                         │
│  - DashboardScene.java                   │
│  - FightersScene.java                    │
│  - MatchmakingScene.java                 │
│  - RankingsScene.java                    │
└──────────────┬──────────────────────────┘
               │
               ↓ Actions utilisateur
┌──────────────────────────────────────────┐
│        CONTROLLER (Contrôleur)            │
│  - MainController.java                    │
│    → Gère ObservableLists                │
│    → Appelle les services                │
└──────────────┬───────────────────────────┘
               │
               ↓ Logique métier
┌──────────────────────────────────────────┐
│         SERVICE (Logique)                 │
│  - SmartFightService.java                │
│    → Orchestration                       │
│    → Appelle DAO + Algorithmes           │
└──────┬────────────────────┬──────────────┘
       │                    │
       ↓                    ↓
┌─────────────┐      ┌──────────────────┐
│     DAO     │      │   ALGORITHM       │
│  (Données)  │      │  (Intelligence)   │
└─────────────┘      └──────────────────┘
       │                    
       ↓                    
┌─────────────────────────────────────────┐
│      MODEL (Entités métier)              │
│  - Fighter.java                          │
│  - MatchProposal.java                    │
│  - Ranking.java                          │
└─────────────┬───────────────────────────┘
              │
              ↓
┌─────────────────────────────────────────┐
│         DATABASE (MySQL)                 │
└─────────────────────────────────────────┘
```

### 🔄 Flux de Données

**Exemple: Générer des matchs**

1. **Vue** : Utilisateur clique sur "Générer les matchs"
2. **Contrôleur** : `controller.generateMatches(10)`
3. **Service** : `service.generateMatches(10)`
4. **DAO** : Récupère les combattants de la BD
5. **Algorithme** : Calcule les meilleurs matchs
6. **Service** : Retourne les propositions
7. **Contrôleur** : Met à jour l'ObservableList
8. **Vue** : TableView se met à jour automatiquement

---

## 4. Schéma de Base de Données

### 🗄️ Tables Principales

```
┌──────────────┐         ┌──────────────┐
│   fighter    │────┬───→│ weight_class │
│              │    │    │              │
│ • id         │    │    │ • id         │
│ • name       │    │    │ • name       │
│ • wins       │    │    │ • min_weight │
│ • losses     │    │    │ • max_weight │
│ • weight_kg  │    │    └──────────────┘
└──────┬───────┘    │
       │            │    ┌──────────────┐
       │            └───→│  discipline  │
       │                 │              │
       │                 │ • id         │
       ↓                 │ • name       │
┌──────────────┐         └──────────────┘
│   ranking    │
│              │
│ • fighter_id │
│ • rank       │
│ • score      │
│ • trend      │
└──────────────┘

       ↓
┌────────────────────┐
│  match_proposal    │
│                    │
│ • fighter1_id      │
│ • fighter2_id      │
│ • match_score      │
│ • status           │
└────────────────────┘
```

### 📋 Relations

- **fighter** → **weight_class** : Many-to-One
- **fighter** → **discipline** : Many-to-One
- **ranking** → **fighter** : One-to-One (par catégorie)
- **match_proposal** → **fighter** : Many-to-One (×2)

---

## 📚 Références Théoriques

### Système ELO
- Inventé par Arpad Elo pour les échecs
- Adapté ici pour les sports de combat
- Principe: La variation du score dépend de la différence de niveau

### Algorithmes de Matchmaking
- Inspiré des systèmes de jeux vidéo (League of Legends, etc.)
- Critères multiples pondérés
- Score de qualité pour prioriser les meilleurs matchs

### Design Patterns
- **MVC**: Séparation des responsabilités
- **DAO**: Abstraction de la persistance
- **Singleton**: Connexion unique à la BD
- **Observer**: JavaFX ObservableList

---

## 🎓 Concepts Pédagogiques Couverts

✅ Programmation Orientée Objet (POO)
✅ Architecture logicielle (MVC)
✅ Bases de données relationnelles (SQL)
✅ Algorithmes et structures de données
✅ Interface graphique (JavaFX)
✅ Design Patterns
✅ JDBC et persistance
✅ Mathématiques appliquées (ELO, pondération)

---

**Document technique - SmartFight AI Matchmaking System**
*Niveau: Licence/Master Informatique*
